import 'dart:typed_data';

import 'package:image_picker/image_picker.dart';

import '../../core/app_config.dart';

/// Chup anh bang ung dung camera cua may.
class CameraService {
  static final ImagePicker _picker = ImagePicker();

  static Future<Uint8List?> capture() async {
    final file = await _picker.pickImage(
      source: ImageSource.camera,
      maxWidth: AppConfig.maxImageSide,
      maxHeight: AppConfig.maxImageSide,
    );
    if (file == null) return null;
    return await file.readAsBytes();
  }
}
