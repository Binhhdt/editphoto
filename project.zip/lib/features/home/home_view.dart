import 'dart:io';

import 'package:flutter/material.dart';

import '../../core/app_config.dart';

enum QuickTool {
  removeBg('Xóa nền', Icons.auto_fix_high),
  beauty('Làm đẹp', Icons.face_retouching_natural),
  template('Template', Icons.dashboard_customize_outlined),
  frame('Khung ảnh', Icons.filter_frames_outlined),
  effects('Hiệu ứng', Icons.auto_awesome),
  sticker('Sticker', Icons.emoji_emotions_outlined),
  erase('Xóa vật thể', Icons.healing),
  blurBg('Mờ nền', Icons.blur_on);

  const QuickTool(this.label, this.icon);
  final String label;
  final IconData icon;
}

const Color _ink = Color(0xFF0B1020);

/// Man hinh chinh (mau B): logo 14, o Chon anh lon, Chup anh, Ghep anh,
/// anh gan day va luoi mo nhanh cong cu.
class HomeView extends StatelessWidget {
  const HomeView({
    super.key,
    required this.recents,
    required this.onPick,
    required this.onCamera,
    required this.onCollage,
    required this.onQuick,
    required this.onOpenRecent,
    required this.onDeleteRecent,
  });

  final List<File> recents;
  final VoidCallback onPick;
  final VoidCallback onCamera;
  final VoidCallback onCollage;
  final ValueChanged<QuickTool> onQuick;
  final ValueChanged<File> onOpenRecent;
  final ValueChanged<File> onDeleteRecent;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                width: 48,
                height: 48,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: AppColors.accent,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Text(
                  '14',
                  style: TextStyle(
                    color: _ink,
                    fontSize: 21,
                    fontWeight: FontWeight.w900,
                    letterSpacing: -1,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Photo Editor',
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.w700)),
                    SizedBox(height: 2),
                    Text('Hôm nay sửa ảnh gì?',
                        style:
                            TextStyle(fontSize: 13, color: AppColors.muted)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          _Tile(
            color: AppColors.accent,
            radius: 22,
            height: 176,
            onTap: onPick,
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Icon(Icons.photo_library_outlined, size: 40, color: _ink),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Chọn ảnh',
                        style: TextStyle(
                            color: _ink,
                            fontSize: 26,
                            fontWeight: FontWeight.w700)),
                    SizedBox(height: 4),
                    Text('Mở ảnh từ thư viện để chỉnh sửa',
                        style: TextStyle(
                            color: _ink,
                            fontSize: 14,
                            fontWeight: FontWeight.w500)),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _SmallTile(
                  icon: Icons.photo_camera_outlined,
                  label: 'Chụp ảnh',
                  onTap: onCamera,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _SmallTile(
                  icon: Icons.grid_view,
                  label: 'Ghép ảnh',
                  onTap: onCollage,
                ),
              ),
            ],
          ),
          if (recents.isNotEmpty) ...[
            const SizedBox(height: 22),
            const _SectionTitle('Chỉnh sửa gần đây'),
            const SizedBox(height: 10),
            SizedBox(
              height: 120,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: recents.length,
                separatorBuilder: (_, __) => const SizedBox(width: 10),
                itemBuilder: (context, i) {
                  final f = recents[i];
                  return ClipRRect(
                    borderRadius: BorderRadius.circular(14),
                    child: Material(
                      color: AppColors.panel,
                      child: InkWell(
                        onTap: () => onOpenRecent(f),
                        onLongPress: () => onDeleteRecent(f),
                        child: SizedBox(
                          width: 100,
                          height: 120,
                          child: Image.file(
                            f,
                            fit: BoxFit.cover,
                            cacheWidth: 300,
                            errorBuilder: (_, __, ___) => const Icon(
                                Icons.broken_image_outlined,
                                color: AppColors.muted),
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
          const SizedBox(height: 22),
          const _SectionTitle('Mở nhanh công cụ'),
          const SizedBox(height: 10),
          GridView.count(
            crossAxisCount: 4,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 0.95,
            children: [
              for (final q in QuickTool.values)
                _Tile(
                  color: AppColors.panel,
                  radius: 14,
                  padding: const EdgeInsets.all(4),
                  onTap: () => onQuick(q),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(q.icon, size: 24, color: AppColors.accent),
                      const SizedBox(height: 8),
                      Text(
                        q.label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 11.5, fontWeight: FontWeight.w500),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
          fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.muted),
    );
  }
}

class _Tile extends StatelessWidget {
  const _Tile({
    required this.color,
    required this.radius,
    required this.onTap,
    required this.child,
    this.height,
    this.padding = const EdgeInsets.all(20),
  });

  final Color color;
  final double radius;
  final VoidCallback onTap;
  final Widget child;
  final double? height;
  final EdgeInsets padding;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: color,
      borderRadius: BorderRadius.circular(radius),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Container(
          height: height,
          width: double.infinity,
          padding: padding,
          child: child,
        ),
      ),
    );
  }
}

class _SmallTile extends StatelessWidget {
  const _SmallTile({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return _Tile(
      color: AppColors.panel,
      radius: 20,
      height: 100,
      padding: const EdgeInsets.all(16),
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Icon(icon, size: 26),
          Text(label,
              style:
                  const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
