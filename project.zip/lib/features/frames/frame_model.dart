import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../../core/image_utils.dart';

enum FrameStyle {
  border('Viền'),
  rounded('Bo góc'),
  polaroid('Polaroid'),
  film('Phim'),
  inner('Viền trong');

  const FrameStyle(this.label);
  final String label;
}

/// Trang thai cong cu Khung anh.
class FrameSession extends ChangeNotifier {
  FrameStyle style = FrameStyle.border;
  Color color = Colors.white;

  /// Do day khung so voi canh ngan cua anh.
  double thickness = 0.05;

  void begin() {
    style = FrameStyle.border;
    color = Colors.white;
    thickness = 0.05;
    notifyListeners();
  }

  void setStyle(FrameStyle s) {
    style = s;
    notifyListeners();
  }

  void setColor(Color c) {
    color = c;
    notifyListeners();
  }

  void setThickness(double v) {
    thickness = v;
    notifyListeners();
  }

  double _b(ui.Image src) =>
      (src.width < src.height ? src.width : src.height) * thickness;

  /// Vi tri anh ben trong khung.
  Rect _photoRect(ui.Image src) {
    final double w = src.width.toDouble(), h = src.height.toDouble();
    final double b = _b(src);
    switch (style) {
      case FrameStyle.border:
      case FrameStyle.rounded:
      case FrameStyle.polaroid:
        return Rect.fromLTWH(b, b, w, h);
      case FrameStyle.film:
        return Rect.fromLTWH(b * 0.5, b * 1.8, w, h);
      case FrameStyle.inner:
        return Rect.fromLTWH(0, 0, w, h);
    }
  }

  Size outSize(ui.Image src) {
    final double w = src.width.toDouble(), h = src.height.toDouble();
    final double b = _b(src);
    switch (style) {
      case FrameStyle.border:
      case FrameStyle.rounded:
        return Size(w + 2 * b, h + 2 * b);
      case FrameStyle.polaroid:
        return Size(w + 2 * b, h + 5 * b);
      case FrameStyle.film:
        return Size(w + b, h + 3.6 * b);
      case FrameStyle.inner:
        return Size(w, h);
    }
  }

  void paint(Canvas canvas, ui.Image src) {
    final out = outSize(src);
    final all = Offset.zero & out;
    final photo = _photoRect(src);
    final double b = _b(src);
    final srcRect =
        Rect.fromLTWH(0, 0, src.width.toDouble(), src.height.toDouble());
    final fill = Paint()..color = color;

    switch (style) {
      case FrameStyle.border:
      case FrameStyle.polaroid:
        canvas.drawRect(all, fill);
        canvas.drawImageRect(src, srcRect, photo, Paint());
        break;
      case FrameStyle.rounded:
        canvas.drawRect(all, fill);
        canvas.save();
        canvas.clipRRect(
            RRect.fromRectAndRadius(photo, Radius.circular(b * 2.5)));
        canvas.drawImageRect(src, srcRect, photo, Paint());
        canvas.restore();
        break;
      case FrameStyle.film:
        canvas.drawRect(all, Paint()..color = Colors.black);
        canvas.drawImageRect(src, srcRect, photo, Paint());
        final double hw = b * 0.8, hh = b * 0.9, step = b * 1.7;
        for (double x = step * 0.4; x + hw < out.width; x += step) {
          for (final double y in [b * 0.45, out.height - b * 0.45 - hh]) {
            canvas.drawRRect(
              RRect.fromRectAndRadius(
                  Rect.fromLTWH(x, y, hw, hh), Radius.circular(b * 0.15)),
              fill,
            );
          }
        }
        break;
      case FrameStyle.inner:
        canvas.drawImageRect(src, srcRect, photo, Paint());
        canvas.drawRect(
          photo.deflate(b * 0.7),
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = b * 0.25
            ..color = color,
        );
        break;
    }
  }

  Future<ui.Image> bake(ui.Image src) {
    final o = outSize(src);
    return renderImage(o.width.round(), o.height.round(), (c) => paint(c, src));
  }
}
