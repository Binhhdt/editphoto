import 'package:flutter/material.dart';

import '../editor/widgets/color_row.dart';
import 'frame_model.dart';

class FramePanel extends StatelessWidget {
  const FramePanel({super.key, required this.session});

  final FrameSession session;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: session,
      builder: (context, _) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            height: 50,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              itemCount: FrameStyle.values.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, i) {
                final st = FrameStyle.values[i];
                return ChoiceChip(
                  showCheckmark: false,
                  label: Text(st.label),
                  selected: session.style == st,
                  onSelected: (_) => session.setStyle(st),
                );
              },
            ),
          ),
          ColorRow(selected: session.color, onSelected: session.setColor),
          Padding(
            padding: const EdgeInsets.only(left: 16, right: 8),
            child: Row(
              children: [
                const Text('Độ dày', style: TextStyle(fontSize: 12)),
                Expanded(
                  child: Slider(
                    min: 0.01,
                    max: 0.15,
                    value: session.thickness,
                    onChanged: session.setThickness,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
