import 'dart:io';

import 'package:share_plus/share_plus.dart';

/// Chia se anh sang ung dung khac.
class ShareService {
  static Future<void> shareFile(File file) async {
    await Share.shareXFiles([XFile(file.path)]);
  }
}
