import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../../core/image_utils.dart';

class TemplateFormat {
  const TemplateFormat(this.label, this.ratio);
  final String label;

  /// Rong / cao.
  final double ratio;
}

const List<TemplateFormat> kTemplateFormats = [
  TemplateFormat('Vuông 1:1', 1),
  TemplateFormat('Dọc 4:5', 4 / 5),
  TemplateFormat('Story 9:16', 9 / 16),
  TemplateFormat('Ngang 16:9', 16 / 9),
  TemplateFormat('Dọc 3:4', 3 / 4),
];

/// Template: dat anh vao khung hinh co ti le san (bai dang, story...),
/// nen la chinh anh do lam mo hoac mot mau.
class TemplateSession extends ChangeNotifier {
  int formatIndex = 0;
  bool blurBackground = true;
  Color color = Colors.white;

  /// Le quanh anh, so voi canh ngan cua khung.
  double margin = 0.06;
  bool rounded = true;

  void begin() {
    formatIndex = 0;
    blurBackground = true;
    color = Colors.white;
    margin = 0.06;
    rounded = true;
    notifyListeners();
  }

  void setFormat(int i) {
    formatIndex = i;
    notifyListeners();
  }

  void setBlur(bool v) {
    blurBackground = v;
    notifyListeners();
  }

  void setColor(Color c) {
    color = c;
    blurBackground = false;
    notifyListeners();
  }

  void setMargin(double v) {
    margin = v;
    notifyListeners();
  }

  void setRounded(bool v) {
    rounded = v;
    notifyListeners();
  }

  Size outSize(ui.Image src) {
    final double l = math.max(src.width, src.height).toDouble();
    final double r = kTemplateFormats[formatIndex].ratio;
    return r >= 1 ? Size(l, l / r) : Size(l * r, l);
  }

  void paint(Canvas canvas, ui.Image src) {
    final out = outSize(src);
    final all = Offset.zero & out;
    final double iw = src.width.toDouble(), ih = src.height.toDouble();

    if (blurBackground) {
      final double s = math.max(out.width / iw, out.height / ih);
      final double sw = out.width / s, sh = out.height / s;
      final double sigma = out.longestSide * 0.03;
      canvas.drawImageRect(
        src,
        Rect.fromLTWH((iw - sw) / 2, (ih - sh) / 2, sw, sh),
        all,
        Paint()
          ..imageFilter = ui.ImageFilter.blur(
              sigmaX: sigma, sigmaY: sigma, tileMode: TileMode.clamp),
      );
      canvas.drawRect(all, Paint()..color = const Color(0x33000000));
    } else {
      canvas.drawRect(all, Paint()..color = color);
    }

    final double m = out.shortestSide * margin;
    final double aw = out.width - 2 * m, ah = out.height - 2 * m;
    final double k = math.min(aw / iw, ah / ih);
    final photo = Rect.fromCenter(
        center: all.center, width: iw * k, height: ih * k);
    final rr = RRect.fromRectAndRadius(
        photo, Radius.circular(rounded ? out.longestSide * 0.025 : 0));

    if (m > 1) {
      canvas.drawRRect(
        rr.shift(Offset(0, out.longestSide * 0.006)),
        Paint()
          ..color = const Color(0x59000000)
          ..maskFilter =
              MaskFilter.blur(BlurStyle.normal, out.longestSide * 0.012),
      );
    }
    canvas.save();
    canvas.clipRRect(rr);
    canvas.drawImageRect(src, Rect.fromLTWH(0, 0, iw, ih), photo,
        Paint()..filterQuality = FilterQuality.medium);
    canvas.restore();
  }

  Future<ui.Image> bake(ui.Image src) {
    final o = outSize(src);
    return renderImage(o.width.round(), o.height.round(), (c) => paint(c, src));
  }
}
