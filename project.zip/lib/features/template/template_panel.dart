import 'package:flutter/material.dart';

import '../editor/widgets/color_row.dart';
import 'template_model.dart';

class TemplatePanel extends StatelessWidget {
  const TemplatePanel({super.key, required this.session});

  final TemplateSession session;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: session,
      builder: (context, _) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            height: 50,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              itemCount: kTemplateFormats.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, i) => ChoiceChip(
                showCheckmark: false,
                label: Text(kTemplateFormats[i].label),
                selected: session.formatIndex == i,
                onSelected: (_) => session.setFormat(i),
              ),
            ),
          ),
          SizedBox(
            height: 44,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: [
                FilterChip(
                  showCheckmark: false,
                  label: const Text('Nền mờ'),
                  selected: session.blurBackground,
                  onSelected: session.setBlur,
                ),
                const SizedBox(width: 8),
                FilterChip(
                  showCheckmark: false,
                  label: const Text('Bo góc'),
                  selected: session.rounded,
                  onSelected: session.setRounded,
                ),
              ],
            ),
          ),
          ColorRow(
            selected: session.blurBackground ? null : session.color,
            onSelected: session.setColor,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 16, right: 8),
            child: Row(
              children: [
                const Text('Lề', style: TextStyle(fontSize: 12)),
                Expanded(
                  child: Slider(
                    min: 0,
                    max: 0.2,
                    value: session.margin,
                    onChanged: session.setMargin,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
