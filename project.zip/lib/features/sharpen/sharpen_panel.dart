import 'package:flutter/material.dart';

import 'sharpen_ops.dart';

class SharpenPanel extends StatelessWidget {
  const SharpenPanel({super.key, required this.session});

  final SharpenSession session;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: session,
      builder: (context, _) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 8, 14),
        child: Row(
          children: [
            const Text('Độ nét', style: TextStyle(fontSize: 12)),
            Expanded(
              child: Slider(
                min: 0,
                max: 2,
                value: session.amount,
                onChanged: session.setAmount,
              ),
            ),
            SizedBox(
              width: 36,
              child: Text('${(session.amount * 50).round()}'),
            ),
          ],
        ),
      ),
    );
  }
}
