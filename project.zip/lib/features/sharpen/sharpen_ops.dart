import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';

import '../../core/image_utils.dart';
import '../../core/temp_image.dart';

class SharpenJob {
  const SharpenJob(this.rgba, this.width, this.height, this.amount);
  final Uint8List rgba;
  final int width;
  final int height;
  final double amount;
}

/// Lam net tung pixel (chay trong isolate rieng de khong giat giao dien).
Uint8List sharpenRgba(SharpenJob j) {
  final src = j.rgba;
  final out = Uint8List(src.length);
  final int w = j.width, h = j.height, row = w * 4;
  final double a = j.amount, center = 1 + 4 * a;
  for (int y = 0; y < h; y++) {
    for (int x = 0; x < w; x++) {
      final int i = (y * w + x) * 4;
      final int up = y > 0 ? i - row : i;
      final int dn = y < h - 1 ? i + row : i;
      final int lf = x > 0 ? i - 4 : i;
      final int rt = x < w - 1 ? i + 4 : i;
      for (int c = 0; c < 3; c++) {
        final double v = src[i + c] * center -
            a * (src[up + c] + src[dn + c] + src[lf + c] + src[rt + c]);
        out[i + c] = v <= 0 ? 0 : (v >= 255 ? 255 : v.round());
      }
      out[i + 3] = src[i + 3];
    }
  }
  return out;
}

Future<ui.Image> sharpenImage(ui.Image src, double amount) async {
  final bytes = await imageToRgba(src);
  final out = await compute(
      sharpenRgba, SharpenJob(bytes, src.width, src.height, amount));
  return imageFromRgba(out, src.width, src.height);
}

/// Phong to anh [factor] lan (noi suy chat luong cao) roi lam net nhe.
Future<ui.Image> upscaleImage(ui.Image src, double factor) async {
  final int w = math.max(1, (src.width * factor).round());
  final int h = math.max(1, (src.height * factor).round());
  final big = await renderImage(w, h, (c) {
    c.drawImageRect(
      src,
      ui.Rect.fromLTWH(0, 0, src.width.toDouble(), src.height.toDouble()),
      ui.Rect.fromLTWH(0, 0, w.toDouble(), h.toDouble()),
      ui.Paint()..filterQuality = ui.FilterQuality.high,
    );
  });
  final out = await sharpenImage(big, 0.35);
  big.dispose();
  return out;
}

/// Trang thai cong cu Lam net, co anh xem truoc thu nho.
class SharpenSession extends ChangeNotifier {
  double amount = 0.6;
  ui.Image? preview;
  ui.Image? _small;
  bool _running = false;
  bool _pending = false;
  int _generation = 0;

  Future<void> begin(ui.Image src) async {
    end();
    final gen = _generation;
    amount = 0.6;
    final int longest = math.max(src.width, src.height);
    final double k = longest > 900 ? 900 / longest : 1.0;
    final int w = math.max(1, (src.width * k).round());
    final int h = math.max(1, (src.height * k).round());
    final small = await renderImage(w, h, (c) {
      c.drawImageRect(
        src,
        ui.Rect.fromLTWH(0, 0, src.width.toDouble(), src.height.toDouble()),
        ui.Rect.fromLTWH(0, 0, w.toDouble(), h.toDouble()),
        ui.Paint()..filterQuality = ui.FilterQuality.medium,
      );
    });
    if (gen != _generation) {
      small.dispose();
      return;
    }
    _small = small;
    _schedule();
  }

  void setAmount(double v) {
    amount = v;
    notifyListeners();
    _schedule();
  }

  Future<void> _schedule() async {
    final small = _small;
    if (small == null) return;
    if (_running) {
      _pending = true;
      return;
    }
    _running = true;
    final gen = _generation;
    try {
      final img = await sharpenImage(small, amount);
      if (gen != _generation) {
        img.dispose();
      } else {
        final old = preview;
        preview = img;
        old?.dispose();
        notifyListeners();
      }
    } catch (_) {
      // Bo qua loi xem truoc.
    } finally {
      _running = false;
    }
    if (_pending && gen == _generation) {
      _pending = false;
      _schedule();
    }
  }

  void end() {
    _generation++;
    _pending = false;
    preview?.dispose();
    preview = null;
    _small?.dispose();
    _small = null;
  }

  @override
  void dispose() {
    end();
    super.dispose();
  }
}
