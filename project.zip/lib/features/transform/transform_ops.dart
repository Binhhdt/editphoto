import 'dart:math' as math;
import 'dart:ui' as ui;

import '../../core/image_utils.dart';

/// Xoay va lat anh that su (tao anh moi).
class TransformOps {
  static Future<ui.Image> rotateRight(ui.Image src) {
    return renderImage(src.height, src.width, (c) {
      c.translate(src.height.toDouble(), 0);
      c.rotate(math.pi / 2);
      c.drawImage(src, ui.Offset.zero, ui.Paint());
    });
  }

  static Future<ui.Image> rotateLeft(ui.Image src) {
    return renderImage(src.height, src.width, (c) {
      c.translate(0, src.width.toDouble());
      c.rotate(-math.pi / 2);
      c.drawImage(src, ui.Offset.zero, ui.Paint());
    });
  }

  static Future<ui.Image> flipHorizontal(ui.Image src) {
    return renderImage(src.width, src.height, (c) {
      c.translate(src.width.toDouble(), 0);
      c.scale(-1, 1);
      c.drawImage(src, ui.Offset.zero, ui.Paint());
    });
  }

  static Future<ui.Image> flipVertical(ui.Image src) {
    return renderImage(src.width, src.height, (c) {
      c.translate(0, src.height.toDouble());
      c.scale(1, -1);
      c.drawImage(src, ui.Offset.zero, ui.Paint());
    });
  }
}
