import 'package:flutter/material.dart';

import '../editor/editor_controller.dart';
import '../editor/widgets/tool_button.dart';

class TransformPanel extends StatelessWidget {
  const TransformPanel({super.key, required this.controller});

  final EditorController controller;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 76,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          ToolButton(
            icon: Icons.rotate_left,
            label: 'Xoay trái',
            onTap: () => controller.rotateLeft(),
          ),
          ToolButton(
            icon: Icons.rotate_right,
            label: 'Xoay phải',
            onTap: () => controller.rotateRight(),
          ),
          ToolButton(
            icon: Icons.flip,
            label: 'Lật ngang',
            onTap: () => controller.flipHorizontal(),
          ),
          ToolButton(
            icon: Icons.flip,
            quarterTurns: 1,
            label: 'Lật dọc',
            onTap: () => controller.flipVertical(),
          ),
        ],
      ),
    );
  }
}
