import 'package:flutter/material.dart';

import 'beauty_model.dart';

class BeautyPanel extends StatelessWidget {
  const BeautyPanel({super.key, required this.session});

  final BeautySession session;

  @override
  Widget build(BuildContext context) {
    Widget row(String label, double value, ValueChanged<double> onChanged) {
      return Padding(
        padding: const EdgeInsets.only(left: 16, right: 8),
        child: Row(
          children: [
            SizedBox(
              width: 56,
              child: Text(label, style: const TextStyle(fontSize: 12)),
            ),
            Expanded(
              child: Slider(min: 0, max: 1, value: value, onChanged: onChanged),
            ),
            SizedBox(width: 32, child: Text('${(value * 100).round()}')),
          ],
        ),
      );
    }

    return ListenableBuilder(
      listenable: session,
      builder: (context, _) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 6),
          row('Mịn da', session.smooth, session.setSmooth),
          row('Sáng da', session.bright, session.setBright),
          const SizedBox(height: 6),
        ],
      ),
    );
  }
}
