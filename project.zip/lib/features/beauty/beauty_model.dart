import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../../core/color_matrix.dart';
import '../../core/image_utils.dart';
import '../ai/face_service.dart';

/// Trang thai cong cu Lam dep khuon mat.
class BeautySession extends ChangeNotifier {
  List<FaceShape> faces = const [];

  /// Do min da 0..1.
  double smooth = 0.6;

  /// Do sang da 0..1.
  double bright = 0.3;

  void begin(List<FaceShape> found) {
    faces = found;
    smooth = 0.6;
    bright = 0.3;
    notifyListeners();
  }

  void setSmooth(double v) {
    smooth = v;
    notifyListeners();
  }

  void setBright(double v) {
    bright = v;
    notifyListeners();
  }

  /// Ve ket qua len canvas theo toa do pixel anh.
  void paint(Canvas canvas, ui.Image src) {
    canvas.drawImage(src, Offset.zero, Paint());
    final brighten = ColorFilter.matrix(CM.offset(bright * 28));
    for (final f in faces) {
      final double side = f.box.shortestSide;
      final double feather = math.max(2.0, side * 0.04);
      final double sigma = math.max(1.5, side * 0.014);
      final layer = f.box.inflate(feather * 4);

      canvas.saveLayer(layer, Paint());
      // 1. Mat na vung da, vien mem.
      canvas.drawPath(
        f.skin,
        Paint()
          ..color = Colors.white
          ..maskFilter = MaskFilter.blur(BlurStyle.normal, feather),
      );
      // 2. Noi dung chi hien trong mat na.
      canvas.saveLayer(layer, Paint()..blendMode = BlendMode.srcIn);
      canvas.clipRect(layer);
      canvas.drawImage(src, Offset.zero, Paint()..colorFilter = brighten);
      if (smooth > 0.01) {
        canvas.drawImage(
          src,
          Offset.zero,
          Paint()
            ..color = Color.fromRGBO(0, 0, 0, smooth * 0.75)
            ..colorFilter = brighten
            ..imageFilter = ui.ImageFilter.blur(
              sigmaX: sigma,
              sigmaY: sigma,
              tileMode: TileMode.clamp,
            ),
        );
      }
      canvas.restore();
      canvas.restore();
    }
  }

  Future<ui.Image> bake(ui.Image src) {
    return renderImage(src.width, src.height, (c) => paint(c, src));
  }
}

class BeautyPainter extends CustomPainter {
  BeautyPainter(this.session, this.src, this.scale) : super(repaint: session);

  final BeautySession session;
  final ui.Image src;
  final double scale;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.clipRect(Offset.zero & size);
    canvas.scale(scale);
    session.paint(canvas, src);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant BeautyPainter oldDelegate) =>
      oldDelegate.src != src || oldDelegate.scale != scale;
}
