import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../../core/app_config.dart';
import '../../core/image_utils.dart';
import '../editor/widgets/color_row.dart';
import '../editor/widgets/fit_painter.dart';

class CollageLayout {
  const CollageLayout(this.label, this.cells);
  final String label;

  /// O anh, toa do 0..1.
  final List<Rect> cells;
}

List<CollageLayout> collageLayoutsFor(int n) {
  final out = <CollageLayout>[
    CollageLayout('Ngang',
        [for (int i = 0; i < n; i++) Rect.fromLTWH(i / n, 0, 1 / n, 1)]),
    CollageLayout('Dọc',
        [for (int i = 0; i < n; i++) Rect.fromLTWH(0, i / n, 1, 1 / n)]),
  ];
  if (n >= 3) {
    final int c = math.sqrt(n).ceil();
    final int r = (n / c).ceil();
    final grid = <Rect>[];
    for (int i = 0; i < n; i++) {
      final int row = i ~/ c, col = i % c;
      final int inRow = row == r - 1 ? n - c * (r - 1) : c;
      grid.add(Rect.fromLTWH(col / inRow, row / r, 1 / inRow, 1 / r));
    }
    out.add(CollageLayout('Lưới', grid));
    out.add(CollageLayout('1 lớn', [
      const Rect.fromLTWH(0, 0, 0.6, 1),
      for (int i = 1; i < n; i++)
        Rect.fromLTWH(0.6, (i - 1) / (n - 1), 0.4, 1 / (n - 1)),
    ]));
  }
  return out;
}

const List<List<Object>> _ratios = [
  ['1:1', 1.0],
  ['4:5', 0.8],
  ['9:16', 0.5625],
  ['4:3', 1.3333],
  ['16:9', 1.7778],
];

/// Man hinh ghep nhieu anh thanh mot anh. Tra ve ui.Image khi bam Xong.
class CollageScreen extends StatefulWidget {
  const CollageScreen({super.key, required this.images});

  final List<ui.Image> images;

  @override
  State<CollageScreen> createState() => _CollageScreenState();
}

class _CollageScreenState extends State<CollageScreen> {
  late final List<CollageLayout> _layouts =
      collageLayoutsFor(widget.images.length);
  int _layout = 0;
  int _ratio = 0;
  double _gap = 0.015;
  Color _color = Colors.white;
  bool _busy = false;

  @override
  void dispose() {
    for (final img in widget.images) {
      img.dispose();
    }
    super.dispose();
  }

  Size get _outSize {
    const double l = 2000;
    final double r = _ratios[_ratio][1] as double;
    return r >= 1 ? Size(l, l / r) : Size(l * r, l);
  }

  void _paint(Canvas canvas) {
    final out = _outSize;
    canvas.drawRect(Offset.zero & out, Paint()..color = _color);
    final double g = out.shortestSide * _gap;
    final area = Rect.fromLTWH(g / 2, g / 2, out.width - g, out.height - g);
    final cells = _layouts[_layout].cells;
    for (int i = 0; i < cells.length && i < widget.images.length; i++) {
      final c = cells[i];
      final cell = Rect.fromLTWH(
        area.left + c.left * area.width,
        area.top + c.top * area.height,
        c.width * area.width,
        c.height * area.height,
      ).deflate(g / 2);
      if (cell.width <= 0 || cell.height <= 0) continue;
      final img = widget.images[i];
      final double s =
          math.max(cell.width / img.width, cell.height / img.height);
      final double sw = cell.width / s, sh = cell.height / s;
      canvas.drawImageRect(
        img,
        Rect.fromLTWH((img.width - sw) / 2, (img.height - sh) / 2, sw, sh),
        cell,
        Paint()..filterQuality = FilterQuality.medium,
      );
    }
  }

  Future<void> _done() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final o = _outSize;
      final result =
          await renderImage(o.width.round(), o.height.round(), _paint);
      if (!mounted) {
        result.dispose();
        return;
      }
      Navigator.pop(context, result);
    } catch (e) {
      if (!mounted) return;
      setState(() => _busy = false);
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Không ghép được ảnh: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    Widget chips(int count, String Function(int) label, int selected,
        ValueChanged<int> onTap) {
      return SizedBox(
        height: 48,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          itemCount: count,
          separatorBuilder: (_, __) => const SizedBox(width: 8),
          itemBuilder: (context, i) => ChoiceChip(
            showCheckmark: false,
            label: Text(label(i)),
            selected: selected == i,
            onSelected: (_) => onTap(i),
          ),
        ),
      );
    }

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            SizedBox(
              height: 52,
              child: Row(
                children: [
                  IconButton(
                    tooltip: 'Hủy',
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(context),
                  ),
                  const Expanded(
                    child: Text(
                      'Ghép ảnh',
                      textAlign: TextAlign.center,
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                  ),
                  IconButton(
                    tooltip: 'Xong',
                    icon: const Icon(Icons.check, color: AppColors.accent),
                    onPressed: _busy ? null : () => _done(),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: CustomPaint(
                  size: Size.infinite,
                  painter: FitPainter(
                    outSize: () => _outSize,
                    paintContent: _paint,
                  ),
                ),
              ),
            ),
            Container(
              color: AppColors.panel,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  chips(_layouts.length, (i) => _layouts[i].label, _layout,
                      (i) => setState(() => _layout = i)),
                  chips(_ratios.length, (i) => _ratios[i][0] as String, _ratio,
                      (i) => setState(() => _ratio = i)),
                  ColorRow(
                    selected: _color,
                    onSelected: (c) => setState(() => _color = c),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 16, right: 8),
                    child: Row(
                      children: [
                        const Text('Khoảng cách',
                            style: TextStyle(fontSize: 12)),
                        Expanded(
                          child: Slider(
                            min: 0,
                            max: 0.06,
                            value: _gap,
                            onChanged: (v) => setState(() => _gap = v),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
