import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../../core/image_utils.dart';

class FontOption {
  const FontOption(this.label, this.family);
  final String label;
  final String? family;
}

/// Font co san trong Android (khong can nhung file font).
const List<FontOption> kFonts = [
  FontOption('Mặc định', null),
  FontOption('Serif', 'serif'),
  FontOption('Mono', 'monospace'),
  FontOption('Hẹp', 'sans-serif-condensed'),
  FontOption('Viết tay', 'cursive'),
  FontOption('Casual', 'casual'),
];

/// Mot khoi chu. Vi tri va co chu tinh theo pixel anh.
class TextItem {
  TextItem({
    required this.text,
    required this.center,
    required this.fontSize,
  });

  String text;
  Offset center;
  double fontSize;
  String? fontFamily;
  Color color = Colors.white;
  bool bold = false;
  bool italic = false;
  double opacity = 1;

  /// Goc xoay, radian.
  double rotation = 0;
}

class TextSession extends ChangeNotifier {
  final List<TextItem> items = [];
  int selectedIndex = -1;
  Size imageSize = Size.zero;

  TextItem? get selected =>
      selectedIndex >= 0 && selectedIndex < items.length
          ? items[selectedIndex]
          : null;

  double get minFont => math.max(4.0, imageSize.shortestSide * 0.03);
  double get maxFont => math.max(8.0, imageSize.shortestSide * 0.6);

  void begin(Size size) {
    items.clear();
    selectedIndex = -1;
    imageSize = size;
    notifyListeners();
  }

  void add(String text) {
    items.add(TextItem(
      text: text,
      center: Offset(imageSize.width / 2, imageSize.height / 2),
      fontSize: imageSize.shortestSide / 9,
    ));
    selectedIndex = items.length - 1;
    notifyListeners();
  }

  void select(int index) {
    selectedIndex = index;
    notifyListeners();
  }

  void update(void Function(TextItem item) change) {
    final item = selected;
    if (item == null) return;
    change(item);
    item.fontSize = item.fontSize.clamp(minFont, maxFont).toDouble();
    notifyListeners();
  }

  void removeSelected() {
    if (selected == null) return;
    items.removeAt(selectedIndex);
    selectedIndex = items.isEmpty ? -1 : items.length - 1;
    notifyListeners();
  }

  TextPainter layout(TextItem item) {
    return TextPainter(
      text: TextSpan(
        text: item.text,
        style: TextStyle(
          fontFamily: item.fontFamily,
          fontSize: item.fontSize,
          height: 1.2,
          color: item.color.withOpacity(item.opacity),
          fontWeight: item.bold ? FontWeight.bold : FontWeight.normal,
          fontStyle: item.italic ? FontStyle.italic : FontStyle.normal,
        ),
      ),
      textAlign: TextAlign.center,
      textDirection: TextDirection.ltr,
    )..layout();
  }

  void paintItem(Canvas canvas, TextItem item) {
    final tp = layout(item);
    canvas.save();
    canvas.translate(item.center.dx, item.center.dy);
    canvas.rotate(item.rotation);
    tp.paint(canvas, Offset(-tp.width / 2, -tp.height / 2));
    canvas.restore();
  }

  void paintAll(Canvas canvas) {
    for (final item in items) {
      paintItem(canvas, item);
    }
  }

  /// Tim khoi chu tai diem [p] (pixel anh). Tra ve -1 neu khong co.
  int hitTest(Offset p) {
    for (int i = items.length - 1; i >= 0; i--) {
      final item = items[i];
      final tp = layout(item);
      final d = p - item.center;
      final cosA = math.cos(-item.rotation);
      final sinA = math.sin(-item.rotation);
      final x = d.dx * cosA - d.dy * sinA;
      final y = d.dx * sinA + d.dy * cosA;
      final pad = item.fontSize * 0.35;
      if (x.abs() <= tp.width / 2 + pad && y.abs() <= tp.height / 2 + pad) {
        return i;
      }
    }
    return -1;
  }

  /// Gop chu vao anh.
  Future<ui.Image> bake(ui.Image src) {
    return renderImage(src.width, src.height, (c) {
      c.drawImage(src, Offset.zero, Paint());
      paintAll(c);
    });
  }
}
