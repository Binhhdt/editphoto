import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../editor/widgets/color_row.dart';
import 'text_model.dart';

enum _Param { size, opacity, rotation }

Future<String?> showTextInputDialog(BuildContext context,
    {String initial = ''}) {
  final ctl = TextEditingController(text: initial);
  return showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Nhập chữ'),
      content: TextField(
        controller: ctl,
        autofocus: true,
        minLines: 1,
        maxLines: 4,
        decoration: const InputDecoration(hintText: 'Nội dung...'),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: const Text('Hủy'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(ctx, ctl.text),
          child: const Text('OK'),
        ),
      ],
    ),
  );
}

class TextPanel extends StatefulWidget {
  const TextPanel({super.key, required this.session});

  final TextSession session;

  @override
  State<TextPanel> createState() => _TextPanelState();
}

class _TextPanelState extends State<TextPanel> {
  _Param _param = _Param.size;

  TextSession get s => widget.session;

  Future<void> _add() async {
    final text = await showTextInputDialog(context);
    if (text == null || text.trim().isEmpty) return;
    s.add(text);
  }

  Future<void> _edit() async {
    final item = s.selected;
    if (item == null) return;
    final text = await showTextInputDialog(context, initial: item.text);
    if (text == null || text.trim().isEmpty) return;
    s.update((i) => i.text = text);
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (context, _) {
        final item = s.selected;
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              height: 48,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                children: [
                  ActionChip(
                    avatar: const Icon(Icons.add, size: 18),
                    label: const Text('Thêm chữ'),
                    onPressed: () => _add(),
                  ),
                  const SizedBox(width: 8),
                  ActionChip(
                    avatar: const Icon(Icons.edit, size: 18),
                    label: const Text('Sửa'),
                    onPressed: item == null ? null : () => _edit(),
                  ),
                  const SizedBox(width: 8),
                  FilterChip(
                    showCheckmark: false,
                    label: const Text('B',
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    selected: item?.bold ?? false,
                    onSelected: item == null
                        ? null
                        : (v) => s.update((i) => i.bold = v),
                  ),
                  const SizedBox(width: 8),
                  FilterChip(
                    showCheckmark: false,
                    label: const Text('I',
                        style: TextStyle(fontStyle: FontStyle.italic)),
                    selected: item?.italic ?? false,
                    onSelected: item == null
                        ? null
                        : (v) => s.update((i) => i.italic = v),
                  ),
                  const SizedBox(width: 8),
                  ActionChip(
                    avatar: const Icon(Icons.delete_outline, size: 18),
                    label: const Text('Xóa'),
                    onPressed: item == null ? null : () => s.removeSelected(),
                  ),
                ],
              ),
            ),
            if (item == null)
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'Bấm "Thêm chữ", sau đó kéo để di chuyển.\n'
                  'Dùng 2 ngón để phóng to, thu nhỏ và xoay.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12, color: Colors.white70),
                ),
              )
            else ...[
              SizedBox(
                height: 44,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  itemCount: kFonts.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (context, i) {
                    final f = kFonts[i];
                    return ChoiceChip(
                      showCheckmark: false,
                      label: Text(f.label,
                          style: TextStyle(fontFamily: f.family)),
                      selected: item.fontFamily == f.family,
                      onSelected: (_) =>
                          s.update((it) => it.fontFamily = f.family),
                    );
                  },
                ),
              ),
              ColorRow(
                selected: item.color,
                onSelected: (c) => s.update((it) => it.color = c),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 12, right: 8),
                child: Row(
                  children: [
                    DropdownButton<_Param>(
                      value: _param,
                      underline: const SizedBox(),
                      style: const TextStyle(fontSize: 13, color: Colors.white),
                      items: const [
                        DropdownMenuItem(
                            value: _Param.size, child: Text('Cỡ chữ')),
                        DropdownMenuItem(
                            value: _Param.opacity, child: Text('Độ mờ')),
                        DropdownMenuItem(
                            value: _Param.rotation, child: Text('Xoay')),
                      ],
                      onChanged: (v) => setState(() => _param = v ?? _param),
                    ),
                    Expanded(child: _slider(item)),
                  ],
                ),
              ),
            ],
          ],
        );
      },
    );
  }

  Widget _slider(TextItem item) {
    switch (_param) {
      case _Param.size:
        return Slider(
          min: s.minFont,
          max: s.maxFont,
          value: item.fontSize.clamp(s.minFont, s.maxFont).toDouble(),
          onChanged: (v) => s.update((i) => i.fontSize = v),
        );
      case _Param.opacity:
        return Slider(
          min: 0.05,
          max: 1,
          value: item.opacity.clamp(0.05, 1.0).toDouble(),
          onChanged: (v) => s.update((i) => i.opacity = v),
        );
      case _Param.rotation:
        double deg = item.rotation * 180 / math.pi;
        deg = (deg + 180) % 360 - 180;
        return Slider(
          min: -180,
          max: 180,
          value: deg.clamp(-180.0, 180.0).toDouble(),
          onChanged: (v) => s.update((i) => i.rotation = v * math.pi / 180),
        );
    }
  }
}
