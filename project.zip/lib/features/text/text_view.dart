import 'package:flutter/material.dart';

import '../../core/app_config.dart';
import 'text_model.dart';

/// Lop hien thi chu va nhan thao tac:
/// cham de chon, 1 ngon keo de di chuyen, 2 ngon de phong to/thu nho va xoay.
class TextView extends StatefulWidget {
  const TextView({super.key, required this.session, required this.scale});

  final TextSession session;
  final double scale;

  @override
  State<TextView> createState() => _TextViewState();
}

class _TextViewState extends State<TextView> {
  double _baseFont = 0;
  double _baseRotation = 0;

  TextSession get s => widget.session;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapUp: (d) => s.select(s.hitTest(d.localPosition / widget.scale)),
      onScaleStart: (d) {
        final hit = s.hitTest(d.localFocalPoint / widget.scale);
        if (hit >= 0 && hit != s.selectedIndex) s.select(hit);
        final item = s.selected;
        if (item != null) {
          _baseFont = item.fontSize;
          _baseRotation = item.rotation;
        }
      },
      onScaleUpdate: (d) {
        s.update((item) {
          final moved = item.center + d.focalPointDelta / widget.scale;
          item.center = Offset(
            moved.dx.clamp(0.0, s.imageSize.width).toDouble(),
            moved.dy.clamp(0.0, s.imageSize.height).toDouble(),
          );
          if (d.pointerCount >= 2 && _baseFont > 0) {
            item.fontSize = _baseFont * d.scale;
            item.rotation = _baseRotation + d.rotation;
          }
        });
      },
      child: ClipRect(
        child: CustomPaint(
          painter: _TextLayerPainter(s, widget.scale),
          size: Size.infinite,
        ),
      ),
    );
  }
}

class _TextLayerPainter extends CustomPainter {
  _TextLayerPainter(this.session, this.scale) : super(repaint: session);

  final TextSession session;
  final double scale;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(scale);
    session.paintAll(canvas);

    final item = session.selected;
    if (item != null) {
      final tp = session.layout(item);
      final pad = item.fontSize * 0.2;
      canvas.translate(item.center.dx, item.center.dy);
      canvas.rotate(item.rotation);
      canvas.drawRect(
        Rect.fromCenter(
          center: Offset.zero,
          width: tp.width + pad * 2,
          height: tp.height + pad * 2,
        ),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5 / scale
          ..color = AppColors.accent,
      );
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _TextLayerPainter oldDelegate) =>
      oldDelegate.scale != scale || oldDelegate.session != session;
}
