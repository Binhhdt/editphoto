import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../../core/image_utils.dart';

enum EffectType {
  vignette('Tối góc'),
  blur('Mờ'),
  glow('Mơ màng'),
  glitch('Lệch màu'),
  tilt('Tilt-shift'),
  leak('Tia sáng');

  const EffectType(this.label);
  final String label;
}

/// Trang thai cong cu Hieu ung nang cao.
class EffectSession extends ChangeNotifier {
  EffectType type = EffectType.vignette;

  /// Cuong do 0..1.
  double amount = 0.6;

  void begin() {
    type = EffectType.vignette;
    amount = 0.6;
    notifyListeners();
  }

  void setType(EffectType t) {
    type = t;
    notifyListeners();
  }

  void setAmount(double v) {
    amount = v;
    notifyListeners();
  }

  Size outSize(ui.Image src) =>
      Size(src.width.toDouble(), src.height.toDouble());

  static const List<double> _onlyR = [
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, //
  ];
  static const List<double> _onlyG = [
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, //
  ];
  static const List<double> _onlyB = [
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, //
  ];

  ui.ImageFilter _blur(double sigma) => ui.ImageFilter.blur(
      sigmaX: sigma, sigmaY: sigma, tileMode: TileMode.clamp);

  void paint(Canvas canvas, ui.Image src) {
    final bounds =
        Rect.fromLTWH(0, 0, src.width.toDouble(), src.height.toDouble());
    final double side = bounds.shortestSide;
    canvas.save();
    canvas.clipRect(bounds);
    switch (type) {
      case EffectType.vignette:
        canvas.drawImage(src, Offset.zero, Paint());
        canvas.drawRect(
          bounds,
          Paint()
            ..shader = ui.Gradient.radial(
              bounds.center,
              bounds.size.longestSide * 0.72,
              [
                const Color(0x00000000),
                Color.fromRGBO(0, 0, 0, amount * 0.9),
              ],
              const [0.45, 1.0],
            ),
        );
        break;
      case EffectType.blur:
        canvas.drawImage(src, Offset.zero,
            Paint()..imageFilter = _blur(0.01 + amount * side * 0.02));
        break;
      case EffectType.glow:
        canvas.drawImage(src, Offset.zero, Paint());
        canvas.drawImage(
          src,
          Offset.zero,
          Paint()
            ..blendMode = BlendMode.screen
            ..color = Color.fromRGBO(0, 0, 0, amount * 0.8)
            ..imageFilter = _blur(side * 0.015),
        );
        break;
      case EffectType.glitch:
        final double d = amount * bounds.width * 0.02;
        canvas.drawRect(bounds, Paint()..color = Colors.black);
        Paint ch(List<double> m) => Paint()
          ..blendMode = BlendMode.plus
          ..colorFilter = ColorFilter.matrix(m);
        canvas.drawImage(src, Offset(-d, 0), ch(_onlyR));
        canvas.drawImage(src, Offset.zero, ch(_onlyG));
        canvas.drawImage(src, Offset(d, 0), ch(_onlyB));
        break;
      case EffectType.tilt:
        canvas.drawImage(src, Offset.zero, Paint());
        canvas.saveLayer(bounds, Paint());
        canvas.drawImage(src, Offset.zero,
            Paint()..imageFilter = _blur(0.5 + amount * side * 0.02));
        canvas.drawRect(
          bounds,
          Paint()
            ..blendMode = BlendMode.dstIn
            ..shader = ui.Gradient.linear(
              bounds.topCenter,
              bounds.bottomCenter,
              const [
                Color(0xFFFFFFFF),
                Color(0x00FFFFFF),
                Color(0x00FFFFFF),
                Color(0xFFFFFFFF),
              ],
              const [0.0, 0.35, 0.65, 1.0],
            ),
        );
        canvas.restore();
        break;
      case EffectType.leak:
        canvas.drawImage(src, Offset.zero, Paint());
        canvas.drawRect(
          bounds,
          Paint()
            ..blendMode = BlendMode.screen
            ..shader = ui.Gradient.linear(
              bounds.topLeft,
              bounds.bottomRight,
              [
                Color.fromRGBO(255, 122, 61, amount * 0.85),
                const Color(0x00FF3D8B),
                Color.fromRGBO(255, 210, 61, amount * 0.55),
              ],
              const [0.0, 0.55, 1.0],
            ),
        );
        break;
    }
    canvas.restore();
  }

  Future<ui.Image> bake(ui.Image src) {
    return renderImage(src.width, src.height, (c) => paint(c, src));
  }
}
