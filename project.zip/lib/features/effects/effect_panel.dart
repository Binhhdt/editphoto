import 'package:flutter/material.dart';

import 'effect_model.dart';

class EffectPanel extends StatelessWidget {
  const EffectPanel({super.key, required this.session});

  final EffectSession session;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: session,
      builder: (context, _) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 16, right: 8, top: 6),
            child: Row(
              children: [
                const Text('Cường độ', style: TextStyle(fontSize: 12)),
                Expanded(
                  child: Slider(
                    min: 0,
                    max: 1,
                    value: session.amount,
                    onChanged: session.setAmount,
                  ),
                ),
                SizedBox(
                    width: 32, child: Text('${(session.amount * 100).round()}')),
              ],
            ),
          ),
          SizedBox(
            height: 52,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              itemCount: EffectType.values.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, i) {
                final t = EffectType.values[i];
                return ChoiceChip(
                  showCheckmark: false,
                  label: Text(t.label),
                  selected: session.type == t,
                  onSelected: (_) => session.setType(t),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
