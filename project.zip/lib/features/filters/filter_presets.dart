import '../../core/color_matrix.dart';

class FilterPreset {
  const FilterPreset(this.name, this.matrix);
  final String name;
  final List<double> matrix;
}

/// Danh sach filter. Them filter moi bang cach them 1 dong vao day.
final List<FilterPreset> kFilters = [
  const FilterPreset('Original', CM.identity),
  FilterPreset(
    'Vivid',
    CM.chain([CM.saturation(1.45), CM.contrast(1.12)]),
  ),
  FilterPreset(
    'Warm',
    CM.chain([CM.scale(1.12, 1.02, 0.86), CM.saturation(1.08)]),
  ),
  FilterPreset(
    'Cool',
    CM.chain([CM.scale(0.88, 1.0, 1.14), CM.saturation(1.05)]),
  ),
  FilterPreset(
    'Vintage',
    CM.chain([
      CM.mix(CM.sepia, 0.55),
      CM.contrast(0.88),
      CM.offset(12),
      CM.saturation(0.85),
    ]),
  ),
  FilterPreset('B&W', CM.chain([CM.saturation(0), CM.contrast(1.1)])),
  const FilterPreset('Sepia', CM.sepia),
  FilterPreset(
    'Dramatic',
    CM.chain([CM.contrast(1.5), CM.saturation(0.7), CM.offset(-10)]),
  ),
];
