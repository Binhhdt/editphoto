import 'package:flutter/material.dart';

import '../../core/app_config.dart';
import '../editor/editor_controller.dart';
import 'filter_presets.dart';

class FilterPanel extends StatelessWidget {
  const FilterPanel({super.key, required this.controller});

  final EditorController controller;

  @override
  Widget build(BuildContext context) {
    final image = controller.image;
    return SizedBox(
      height: 104,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        itemCount: kFilters.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (context, i) {
          final f = kFilters[i];
          final selected = controller.filterIndex == i;
          return GestureDetector(
            onTap: () => controller.setFilter(i),
            child: Column(
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: selected ? AppColors.accent : Colors.transparent,
                      width: 2.5,
                    ),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(7),
                    child: ColorFiltered(
                      colorFilter: ColorFilter.matrix(f.matrix),
                      child: RawImage(
                        image: image,
                        fit: BoxFit.cover,
                        filterQuality: FilterQuality.low,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  f.name,
                  style: TextStyle(
                    fontSize: 11,
                    color: selected ? AppColors.accent : Colors.white,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
