import 'dart:typed_data';

import 'package:image_picker/image_picker.dart';

import '../../core/app_config.dart';

/// Chon anh tu thu vien Android (JPG, PNG, WebP).
class ImagePickerService {
  static final ImagePicker _picker = ImagePicker();

  static Future<Uint8List?> pickFromGallery() async {
    final file = await _picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: AppConfig.maxImageSide,
      maxHeight: AppConfig.maxImageSide,
    );
    if (file == null) return null;
    return await file.readAsBytes();
  }

  /// Chon nhieu anh cung luc (dung cho Ghep anh).
  static Future<List<Uint8List>> pickMultiple() async {
    final files = await _picker.pickMultiImage(
      maxWidth: 1600,
      maxHeight: 1600,
    );
    final out = <Uint8List>[];
    for (final f in files) {
      out.add(await f.readAsBytes());
    }
    return out;
  }
}
