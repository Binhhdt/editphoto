import 'dart:typed_data';

import 'package:image_picker/image_picker.dart';

import '../../core/app_config.dart';

/// Chon anh tu thu vien Android (JPG, PNG, WebP).
class ImagePickerService {
  static final ImagePicker _picker = ImagePicker();

  static Future<Uint8List?> pickFromGallery() async {
    final file = await _picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: AppConfig.maxImageSide,
      maxHeight: AppConfig.maxImageSide,
    );
    if (file == null) return null;
    return await file.readAsBytes();
  }
}
