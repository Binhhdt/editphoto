import 'package:flutter/material.dart';

import '../../core/app_config.dart';
import 'export_service.dart';

class ExportRequest {
  const ExportRequest(this.options, {required this.share});
  final ExportOptions options;
  final bool share;
}

const List<double> _scales = [1.0, 0.75, 0.5, 0.25];

/// Bang chon dinh dang, chat luong, do phan giai.
Future<ExportRequest?> showExportSheet(
  BuildContext context, {
  required int width,
  required int height,
}) {
  return showModalBottomSheet<ExportRequest>(
    context: context,
    backgroundColor: AppColors.panel,
    isScrollControlled: true,
    builder: (ctx) => _ExportSheet(width: width, height: height),
  );
}

class _ExportSheet extends StatefulWidget {
  const _ExportSheet({required this.width, required this.height});

  final int width;
  final int height;

  @override
  State<_ExportSheet> createState() => _ExportSheetState();
}

class _ExportSheetState extends State<_ExportSheet> {
  ExportFormat _format = ExportFormat.jpg;
  double _quality = 90;
  double _scale = 1.0;

  ExportOptions get _options => ExportOptions(
        format: _format,
        quality: _quality.round(),
        scale: _scale,
      );

  @override
  Widget build(BuildContext context) {
    final isPng = _format == ExportFormat.png;
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Xuất ảnh',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            const Text('Định dạng'),
            const SizedBox(height: 6),
            Wrap(
              spacing: 8,
              children: [
                for (final f in ExportFormat.values)
                  ChoiceChip(
                    showCheckmark: false,
                    label: Text(f.label),
                    selected: _format == f,
                    onSelected: (_) => setState(() => _format = f),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            Text(isPng
                ? 'Chất lượng: PNG không nén mất dữ liệu'
                : 'Chất lượng: ${_quality.round()}%'),
            Slider(
              min: 10,
              max: 100,
              divisions: 18,
              value: _quality,
              onChanged: isPng ? null : (v) => setState(() => _quality = v),
            ),
            const Text('Độ phân giải'),
            const SizedBox(height: 6),
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: [
                for (final k in _scales)
                  ChoiceChip(
                    showCheckmark: false,
                    label: Text(
                        '${(widget.width * k).round()} × ${(widget.height * k).round()}'),
                    selected: _scale == k,
                    onSelected: (_) => setState(() => _scale = k),
                  ),
              ],
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.share),
                    label: const Text('Chia sẻ'),
                    onPressed: () => Navigator.pop(
                        context, ExportRequest(_options, share: true)),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton.icon(
                    icon: const Icon(Icons.save_alt),
                    label: const Text('Lưu'),
                    onPressed: () => Navigator.pop(
                        context, ExportRequest(_options, share: false)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
