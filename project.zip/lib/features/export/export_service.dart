import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';

import '../../core/image_utils.dart';

enum ExportFormat {
  jpg('JPG', 'jpg'),
  png('PNG', 'png'),
  webp('WebP', 'webp');

  const ExportFormat(this.label, this.extension);
  final String label;
  final String extension;
}

class ExportOptions {
  const ExportOptions({
    required this.format,
    required this.quality,
    required this.scale,
  });

  final ExportFormat format;

  /// 1..100, chi dung cho JPG va WebP.
  final int quality;

  /// Ti le do phan giai so voi anh dang sua (0..1).
  final double scale;
}

class ExportService {
  /// Xuat anh ra file tam theo dinh dang da chon.
  static Future<File> renderToFile(ui.Image image, ExportOptions o) async {
    final int w = math.max(1, (image.width * o.scale).round());
    final int h = math.max(1, (image.height * o.scale).round());
    final dst = ui.Rect.fromLTWH(0, 0, w.toDouble(), h.toDouble());

    final out = await renderImage(w, h, (c) {
      if (o.format == ExportFormat.jpg) {
        // JPG khong co nen trong suot -> to nen trang.
        c.drawRect(dst, ui.Paint()..color = const ui.Color(0xFFFFFFFF));
      }
      c.drawImageRect(
        image,
        ui.Rect.fromLTWH(0, 0, image.width.toDouble(), image.height.toDouble()),
        dst,
        ui.Paint()..filterQuality = ui.FilterQuality.high,
      );
    });
    final data = await out.toByteData(format: ui.ImageByteFormat.png);
    out.dispose();
    if (data == null) {
      throw Exception('Không mã hóa được ảnh');
    }
    Uint8List bytes = data.buffer.asUint8List();

    if (o.format != ExportFormat.png) {
      bytes = await FlutterImageCompress.compressWithList(
        bytes,
        minWidth: w,
        minHeight: h,
        quality: o.quality,
        format: o.format == ExportFormat.jpg
            ? CompressFormat.jpeg
            : CompressFormat.webp,
      );
    }

    final dir = await getTemporaryDirectory();
    final name =
        'PhotoEditor_${DateTime.now().millisecondsSinceEpoch}.${o.format.extension}';
    final file = File('${dir.path}/$name');
    await file.writeAsBytes(bytes, flush: true);
    return file;
  }

  /// Luu file vao thu vien anh Android (album PhotoEditor).
  static Future<void> saveToGallery(File file) async {
    final ok = await Gal.hasAccess(toAlbum: true);
    if (!ok) {
      await Gal.requestAccess(toAlbum: true);
    }
    await Gal.putImage(file.path, album: 'PhotoEditor');
  }
}
