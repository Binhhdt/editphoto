import 'dart:ui' as ui;

/// Lich su chinh sua: moi buoc la mot anh da xu ly xong.
class HistoryManager {
  HistoryManager({required this.maxSteps});

  final int maxSteps;
  final List<ui.Image> _stack = [];
  int _index = -1;

  ui.Image? get current => _index >= 0 ? _stack[_index] : null;
  bool get canUndo => _index > 0;
  bool get canRedo => _index >= 0 && _index < _stack.length - 1;

  void start(ui.Image first) {
    clear();
    _stack.add(first);
    _index = 0;
  }

  void push(ui.Image image) {
    // Bo cac buoc Redo phia sau.
    while (_stack.length > _index + 1) {
      _stack.removeLast().dispose();
    }
    _stack.add(image);
    _index = _stack.length - 1;
    // Gioi han bo nho.
    while (_stack.length > maxSteps) {
      _stack.removeAt(0).dispose();
      _index--;
    }
  }

  bool undo() {
    if (!canUndo) return false;
    _index--;
    return true;
  }

  bool redo() {
    if (!canRedo) return false;
    _index++;
    return true;
  }

  void clear() {
    for (final img in _stack) {
      img.dispose();
    }
    _stack.clear();
    _index = -1;
  }
}
