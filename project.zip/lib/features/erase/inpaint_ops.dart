import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';

import '../../core/image_utils.dart';
import '../../core/temp_image.dart';
import '../draw/draw_model.dart';

class InpaintJob {
  const InpaintJob(this.rgba, this.mask, this.width, this.height);
  final Uint8List rgba;

  /// 1 = pixel can lap, 0 = pixel giu nguyen.
  final Uint8List mask;
  final int width;
  final int height;
}

/// Lap vung bi xoa bang mau cua vung xung quanh (chay trong isolate).
/// Buoc 1: lan dan tu mep vao trong. Buoc 2: lam muot vung vua lap.
Uint8List inpaintRgba(InpaintJob j) {
  final int w = j.width, h = j.height, n = w * h;
  final px = Uint8List.fromList(j.rgba);
  final state = Uint8List.fromList(j.mask); // 0 biet, 1 chua biet, 2 da lap
  final frontier = <int>[];
  final colors = <int>[];

  while (true) {
    frontier.clear();
    colors.clear();
    for (int p = 0; p < n; p++) {
      if (state[p] != 1) continue;
      final int x = p % w, y = p ~/ w;
      int r = 0, g = 0, b = 0, cnt = 0;
      for (int dy = -1; dy <= 1; dy++) {
        final int yy = y + dy;
        if (yy < 0 || yy >= h) continue;
        for (int dx = -1; dx <= 1; dx++) {
          final int xx = x + dx;
          if (xx < 0 || xx >= w || (dx == 0 && dy == 0)) continue;
          final int q = yy * w + xx;
          if (state[q] == 1) continue;
          final int o = q * 4;
          r += px[o];
          g += px[o + 1];
          b += px[o + 2];
          cnt++;
        }
      }
      if (cnt > 0) {
        frontier.add(p);
        colors.add(r ~/ cnt);
        colors.add(g ~/ cnt);
        colors.add(b ~/ cnt);
      }
    }
    if (frontier.isEmpty) break;
    for (int k = 0; k < frontier.length; k++) {
      final int p = frontier[k], o = p * 4;
      px[o] = colors[k * 3];
      px[o + 1] = colors[k * 3 + 1];
      px[o + 2] = colors[k * 3 + 2];
      px[o + 3] = 255;
      state[p] = 2;
    }
  }

  final filled = <int>[];
  for (int p = 0; p < n; p++) {
    if (state[p] == 2) filled.add(p);
  }
  for (int iter = 0; iter < 60; iter++) {
    for (final p in filled) {
      final int x = p % w, y = p ~/ w, o = p * 4;
      final int l = x > 0 ? o - 4 : o;
      final int r = x < w - 1 ? o + 4 : o;
      final int u = y > 0 ? o - w * 4 : o;
      final int d = y < h - 1 ? o + w * 4 : o;
      for (int c = 0; c < 3; c++) {
        px[o + c] = (px[l + c] + px[r + c] + px[u + c] + px[d + c] + 2) >> 2;
      }
    }
  }
  return px;
}

/// Xoa vat the: [mask] chua cac net nguoi dung to len vat can xoa.
Future<ui.Image> removeObject(ui.Image src, DrawSession mask) async {
  // Khung bao quanh vung to.
  double l = double.infinity, t = double.infinity, r = -1, b = -1;
  for (final s in mask.strokes) {
    final double half = s.width / 2 + 2;
    for (final p in s.points) {
      l = math.min(l, p.dx - half);
      t = math.min(t, p.dy - half);
      r = math.max(r, p.dx + half);
      b = math.max(b, p.dy + half);
    }
  }
  if (r < l || b < t) throw Exception('Chưa tô vùng cần xóa');
  final double margin = math.max(24.0, math.max(r - l, b - t) * 0.35);
  final region = ui.Rect.fromLTRB(
    math.max(0.0, (l - margin).floorToDouble()),
    math.max(0.0, (t - margin).floorToDouble()),
    math.min(src.width.toDouble(), (r + margin).ceilToDouble()),
    math.min(src.height.toDouble(), (b + margin).ceilToDouble()),
  );
  if (region.width < 2 || region.height < 2) {
    throw Exception('Vùng tô không hợp lệ');
  }

  // Lam viec tren ban thu nho de nhanh.
  final double k = math.min(1.0, 512 / math.max(region.width, region.height));
  final int w = math.max(2, (region.width * k).round());
  final int h = math.max(2, (region.height * k).round());
  final work = ui.Rect.fromLTWH(0, 0, w.toDouble(), h.toDouble());

  final regionImg = await renderImage(w, h, (c) {
    c.drawImageRect(
        src, region, work, ui.Paint()..filterQuality = ui.FilterQuality.medium);
  });
  final maskImg = await renderImage(w, h, (c) {
    c.scale(w / region.width, h / region.height);
    c.translate(-region.left, -region.top);
    mask.paintStrokes(c, region, overrideColor: const ui.Color(0xFFFFFFFF));
  });
  final rgba = await imageToRgba(regionImg);
  final maskRgba = await imageToRgba(maskImg);
  regionImg.dispose();
  maskImg.dispose();

  final flags = Uint8List(w * h);
  int unknown = 0;
  for (int i = 0; i < w * h; i++) {
    if (maskRgba[i * 4 + 3] > 40) {
      flags[i] = 1;
      unknown++;
    }
  }
  if (unknown == 0) throw Exception('Chưa tô vùng cần xóa');
  if (unknown >= w * h) {
    throw Exception('Vùng tô quá lớn, không còn nền xung quanh để lấp');
  }

  final out = await compute(inpaintRgba, InpaintJob(rgba, flags, w, h));
  final filled = await imageFromRgba(out, w, h);

  final result = await renderImage(src.width, src.height, (c) {
    c.drawImage(src, ui.Offset.zero, ui.Paint());
    c.saveLayer(region, ui.Paint());
    mask.paintStrokes(c, region, overrideColor: const ui.Color(0xFFFFFFFF));
    c.saveLayer(region, ui.Paint()..blendMode = ui.BlendMode.srcIn);
    c.drawImageRect(filled, work, region,
        ui.Paint()..filterQuality = ui.FilterQuality.medium);
    c.restore();
    c.restore();
  });
  filled.dispose();
  return result;
}
