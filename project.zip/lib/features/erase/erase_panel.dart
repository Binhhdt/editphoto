import 'package:flutter/material.dart';

import '../draw/draw_model.dart';

class ErasePanel extends StatelessWidget {
  const ErasePanel({super.key, required this.session});

  final DrawSession session;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: session,
      builder: (context, _) {
        final empty = session.strokes.isEmpty;
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 10, 16, 2),
              child: Text(
                'Tô kín vật cần xóa rồi bấm dấu ✓ ở góc trên.',
                style: TextStyle(fontSize: 12, color: Colors.white70),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 16, right: 8),
              child: Row(
                children: [
                  const Text('Cỡ cọ', style: TextStyle(fontSize: 12)),
                  Expanded(
                    child: Slider(
                      min: 8,
                      max: 80,
                      value: session.size.clamp(8.0, 80.0).toDouble(),
                      onChanged: session.setSize,
                    ),
                  ),
                  IconButton(
                    tooltip: 'Lùi 1 nét',
                    icon: const Icon(Icons.undo),
                    onPressed: empty ? null : () => session.undoLast(),
                  ),
                  IconButton(
                    tooltip: 'Xóa hết vùng tô',
                    icon: const Icon(Icons.delete_outline),
                    onPressed: empty ? null : () => session.clearAll(),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}
