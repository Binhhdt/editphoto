import 'package:flutter/material.dart';

import '../editor/editor_controller.dart';

class CropRatio {
  const CropRatio(this.label, this.value);
  final String label;
  final double? value;
}

const List<CropRatio> kCropRatios = [
  CropRatio('Tự do', null),
  CropRatio('1:1', 1),
  CropRatio('4:3', 4 / 3),
  CropRatio('16:9', 16 / 9),
  CropRatio('9:16', 9 / 16),
];

class CropPanel extends StatelessWidget {
  const CropPanel({super.key, required this.controller});

  final EditorController controller;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 64,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        itemCount: kCropRatios.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) {
          final r = kCropRatios[i];
          return ChoiceChip(
            showCheckmark: false,
            label: Text(r.label),
            selected: controller.cropRatio == r.value,
            onSelected: (_) => controller.setCropRatio(r.value),
          );
        },
      ),
    );
  }
}
