import 'dart:ui' as ui;

import '../../core/image_utils.dart';

/// Cat anh theo vung [rect] (toa do pixel cua anh).
Future<ui.Image> cropImage(ui.Image src, ui.Rect rect) {
  final int l = rect.left.round().clamp(0, src.width - 1).toInt();
  final int t = rect.top.round().clamp(0, src.height - 1).toInt();
  final int r = rect.right.round().clamp(l + 1, src.width).toInt();
  final int b = rect.bottom.round().clamp(t + 1, src.height).toInt();
  final int w = r - l;
  final int h = b - t;
  return renderImage(w, h, (c) {
    c.drawImageRect(
      src,
      ui.Rect.fromLTRB(l.toDouble(), t.toDouble(), r.toDouble(), b.toDouble()),
      ui.Rect.fromLTWH(0, 0, w.toDouble(), h.toDouble()),
      ui.Paint(),
    );
  });
}
