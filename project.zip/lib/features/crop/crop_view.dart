import 'dart:math' as math;

import 'package:flutter/material.dart';

enum _Handle { none, topLeft, topRight, bottomLeft, bottomRight, move }

/// Khung cat: keo 4 goc de doi kich thuoc, keo ben trong de di chuyen.
class CropView extends StatefulWidget {
  const CropView({
    super.key,
    required this.child,
    required this.size,
    required this.scale,
    required this.ratio,
    required this.onChanged,
  });

  final Widget child;

  /// Kich thuoc anh tren man hinh.
  final Size size;

  /// Ti le man hinh / pixel anh.
  final double scale;

  /// Ti le rong/cao bi khoa, null = tu do.
  final double? ratio;

  /// Tra ve vung cat theo pixel anh.
  final ValueChanged<Rect> onChanged;

  @override
  State<CropView> createState() => _CropViewState();
}

class _CropViewState extends State<CropView> {
  static const double _minSize = 48;
  static const double _touch = 44;

  late Rect _rect;
  _Handle _handle = _Handle.none;

  @override
  void initState() {
    super.initState();
    _reset();
  }

  @override
  void didUpdateWidget(covariant CropView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.ratio != widget.ratio || oldWidget.size != widget.size) {
      _reset();
    }
  }

  void _reset() {
    final s = widget.size;
    final r = widget.ratio;
    if (r == null) {
      _rect = Offset.zero & s;
    } else {
      double w = s.width;
      double h = w / r;
      if (h > s.height) {
        h = s.height;
        w = h * r;
      }
      _rect = Rect.fromCenter(
        center: Offset(s.width / 2, s.height / 2),
        width: w,
        height: h,
      );
    }
    _report();
  }

  void _report() {
    final k = widget.scale;
    widget.onChanged(Rect.fromLTRB(
      _rect.left / k,
      _rect.top / k,
      _rect.right / k,
      _rect.bottom / k,
    ));
  }

  void _onStart(DragStartDetails d) {
    final p = d.localPosition;
    final corners = <_Handle, Offset>{
      _Handle.topLeft: _rect.topLeft,
      _Handle.topRight: _rect.topRight,
      _Handle.bottomLeft: _rect.bottomLeft,
      _Handle.bottomRight: _rect.bottomRight,
    };
    _Handle best = _Handle.none;
    double bestDist = _touch;
    corners.forEach((h, o) {
      final dist = (o - p).distance;
      if (dist < bestDist) {
        bestDist = dist;
        best = h;
      }
    });
    if (best == _Handle.none && _rect.contains(p)) best = _Handle.move;
    _handle = best;
  }

  void _onUpdate(DragUpdateDetails d) {
    if (_handle == _Handle.none) return;
    setState(() {
      if (_handle == _Handle.move) {
        final double loX = math.min(0.0, -_rect.left);
        final double hiX = math.max(0.0, widget.size.width - _rect.right);
        final double loY = math.min(0.0, -_rect.top);
        final double hiY = math.max(0.0, widget.size.height - _rect.bottom);
        final dx = d.delta.dx.clamp(loX, hiX).toDouble();
        final dy = d.delta.dy.clamp(loY, hiY).toDouble();
        _rect = _rect.shift(Offset(dx, dy));
      } else {
        _dragCorner(d.localPosition);
      }
    });
    _report();
  }

  void _dragCorner(Offset p) {
    final left = _handle == _Handle.topLeft || _handle == _Handle.bottomLeft;
    final top = _handle == _Handle.topLeft || _handle == _Handle.topRight;
    // Goc doi dien dung yen.
    final double ax = left ? _rect.right : _rect.left;
    final double ay = top ? _rect.bottom : _rect.top;
    final double maxW = math.max(1.0, left ? ax : widget.size.width - ax);
    final double maxH = math.max(1.0, top ? ay : widget.size.height - ay);
    final double minW = math.min(_minSize, maxW);
    final double minH = math.min(_minSize, maxH);

    double w = (left ? ax - p.dx : p.dx - ax).clamp(minW, maxW).toDouble();
    double h = (top ? ay - p.dy : p.dy - ay).clamp(minH, maxH).toDouble();

    final r = widget.ratio;
    if (r != null) {
      h = w / r;
      if (h > maxH) {
        h = maxH;
        w = h * r;
      }
    }
    _rect = Rect.fromLTRB(
      left ? ax - w : ax,
      top ? ay - h : ay,
      left ? ax : ax + w,
      top ? ay : ay + h,
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onPanStart: _onStart,
      onPanUpdate: _onUpdate,
      onPanEnd: (_) => _handle = _Handle.none,
      child: Stack(
        children: [
          widget.child,
          Positioned.fill(
            child: CustomPaint(painter: _CropPainter(_rect)),
          ),
        ],
      ),
    );
  }
}

class _CropPainter extends CustomPainter {
  _CropPainter(this.rect);

  final Rect rect;

  @override
  void paint(Canvas canvas, Size size) {
    final dim = Paint()..color = Colors.black.withOpacity(0.6);
    canvas.drawRect(Rect.fromLTRB(0, 0, size.width, rect.top), dim);
    canvas.drawRect(Rect.fromLTRB(0, rect.bottom, size.width, size.height), dim);
    canvas.drawRect(Rect.fromLTRB(0, rect.top, rect.left, rect.bottom), dim);
    canvas.drawRect(
        Rect.fromLTRB(rect.right, rect.top, size.width, rect.bottom), dim);

    final grid = Paint()
      ..color = Colors.white.withOpacity(0.4)
      ..strokeWidth = 1;
    for (int i = 1; i < 3; i++) {
      final x = rect.left + rect.width * i / 3;
      final y = rect.top + rect.height * i / 3;
      canvas.drawLine(Offset(x, rect.top), Offset(x, rect.bottom), grid);
      canvas.drawLine(Offset(rect.left, y), Offset(rect.right, y), grid);
    }

    final border = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    canvas.drawRect(rect, border);

    final handle = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.square;
    final double len = math.min(22.0, math.min(rect.width, rect.height) / 3);
    void corner(Offset o, double sx, double sy) {
      canvas.drawLine(o, o + Offset(len * sx, 0), handle);
      canvas.drawLine(o, o + Offset(0, len * sy), handle);
    }

    corner(rect.topLeft, 1, 1);
    corner(rect.topRight, -1, 1);
    corner(rect.bottomLeft, 1, -1);
    corner(rect.bottomRight, -1, -1);
  }

  @override
  bool shouldRepaint(covariant _CropPainter oldDelegate) =>
      oldDelegate.rect != rect;
}
