import 'package:flutter/material.dart';

import 'draw_model.dart';

/// Lop nhan cham de ve truc tiep len anh.
class DrawView extends StatefulWidget {
  const DrawView({super.key, required this.session, required this.scale});

  final DrawSession session;
  final double scale;

  @override
  State<DrawView> createState() => _DrawViewState();
}

class _DrawViewState extends State<DrawView> {
  int? _pointer;

  Offset _toImage(Offset local) => local / widget.scale;

  @override
  Widget build(BuildContext context) {
    return Listener(
      behavior: HitTestBehavior.opaque,
      onPointerDown: (e) {
        if (_pointer != null) return;
        _pointer = e.pointer;
        widget.session.startStroke(_toImage(e.localPosition), widget.scale);
      },
      onPointerMove: (e) {
        if (e.pointer != _pointer) return;
        widget.session.extendStroke(_toImage(e.localPosition));
      },
      onPointerUp: (e) {
        if (e.pointer == _pointer) _pointer = null;
      },
      onPointerCancel: (e) {
        if (e.pointer == _pointer) _pointer = null;
      },
      child: ClipRect(
        child: CustomPaint(
          painter: _DrawPainter(widget.session, widget.scale),
          size: Size.infinite,
        ),
      ),
    );
  }
}

class _DrawPainter extends CustomPainter {
  _DrawPainter(this.session, this.scale) : super(repaint: session);

  final DrawSession session;
  final double scale;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(scale);
    session.paintStrokes(
      canvas,
      Rect.fromLTWH(0, 0, size.width / scale, size.height / scale),
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _DrawPainter oldDelegate) =>
      oldDelegate.scale != scale || oldDelegate.session != session;
}
