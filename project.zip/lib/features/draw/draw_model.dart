import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../../core/image_utils.dart';

/// Mot net ve. Toa do va do day tinh theo pixel anh.
class Stroke {
  Stroke({
    required this.color,
    required this.width,
    required this.eraser,
    required Offset first,
  }) : points = [first];

  final List<Offset> points;
  final Color color;
  final double width;
  final bool eraser;
}

/// Trang thai cong cu Ve trong mot lan mo.
class DrawSession extends ChangeNotifier {
  final List<Stroke> strokes = [];
  Color color = const Color(0xFFFF3B30);

  /// Do day net theo diem man hinh.
  double size = 8;
  bool eraser = false;

  void begin() {
    strokes.clear();
    eraser = false;
    notifyListeners();
  }

  void setColor(Color c) {
    color = c;
    eraser = false;
    notifyListeners();
  }

  void setSize(double v) {
    size = v;
    notifyListeners();
  }

  void setEraser(bool v) {
    eraser = v;
    notifyListeners();
  }

  void startStroke(Offset imagePoint, double scale) {
    strokes.add(Stroke(
      color: color,
      width: size / scale,
      eraser: eraser,
      first: imagePoint,
    ));
    notifyListeners();
  }

  void extendStroke(Offset imagePoint) {
    if (strokes.isEmpty) return;
    strokes.last.points.add(imagePoint);
    notifyListeners();
  }

  void undoLast() {
    if (strokes.isEmpty) return;
    strokes.removeLast();
    notifyListeners();
  }

  void clearAll() {
    strokes.clear();
    notifyListeners();
  }

  /// Ve tat ca net len canvas (toa do pixel anh).
  /// Tay chi xoa net ve, khong xoa anh nen.
  void paintStrokes(Canvas canvas, Rect bounds) {
    canvas.saveLayer(bounds, Paint());
    for (final s in strokes) {
      final p = Paint()
        ..color = s.color
        ..strokeWidth = s.width
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..isAntiAlias = true;
      if (s.eraser) p.blendMode = BlendMode.clear;

      if (s.points.length == 1) {
        p.style = PaintingStyle.fill;
        canvas.drawCircle(s.points.first, s.width / 2, p);
        continue;
      }
      p.style = PaintingStyle.stroke;
      final path = Path()..moveTo(s.points.first.dx, s.points.first.dy);
      for (int i = 1; i < s.points.length - 1; i++) {
        final a = s.points[i];
        final n = s.points[i + 1];
        path.quadraticBezierTo(
            a.dx, a.dy, (a.dx + n.dx) / 2, (a.dy + n.dy) / 2);
      }
      path.lineTo(s.points.last.dx, s.points.last.dy);
      canvas.drawPath(path, p);
    }
    canvas.restore();
  }

  /// Gop net ve vao anh.
  Future<ui.Image> bake(ui.Image src) {
    final bounds =
        Rect.fromLTWH(0, 0, src.width.toDouble(), src.height.toDouble());
    return renderImage(src.width, src.height, (c) {
      c.drawImage(src, Offset.zero, Paint());
      paintStrokes(c, bounds);
    });
  }
}
