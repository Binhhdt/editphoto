import 'package:flutter/material.dart';

import '../editor/widgets/color_row.dart';
import 'draw_model.dart';

class DrawPanel extends StatelessWidget {
  const DrawPanel({super.key, required this.session});

  final DrawSession session;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: session,
      builder: (context, _) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              height: 48,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                children: [
                  ChoiceChip(
                    showCheckmark: false,
                    avatar: const Icon(Icons.brush, size: 18),
                    label: const Text('Bút'),
                    selected: !session.eraser,
                    onSelected: (_) => session.setEraser(false),
                  ),
                  const SizedBox(width: 8),
                  ChoiceChip(
                    showCheckmark: false,
                    avatar: const Icon(Icons.auto_fix_normal, size: 18),
                    label: const Text('Tẩy'),
                    selected: session.eraser,
                    onSelected: (_) => session.setEraser(true),
                  ),
                  const SizedBox(width: 8),
                  ActionChip(
                    avatar: const Icon(Icons.undo, size: 18),
                    label: const Text('Lùi 1 nét'),
                    onPressed: session.strokes.isEmpty
                        ? null
                        : () => session.undoLast(),
                  ),
                  const SizedBox(width: 8),
                  ActionChip(
                    avatar: const Icon(Icons.delete_outline, size: 18),
                    label: const Text('Xóa hết'),
                    onPressed: session.strokes.isEmpty
                        ? null
                        : () => session.clearAll(),
                  ),
                ],
              ),
            ),
            ColorRow(
              selected: session.eraser ? null : session.color,
              onSelected: session.setColor,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 16, right: 8),
              child: Row(
                children: [
                  const Text('Cỡ nét', style: TextStyle(fontSize: 12)),
                  Expanded(
                    child: Slider(
                      min: 2,
                      max: 60,
                      value: session.size,
                      onChanged: session.setSize,
                    ),
                  ),
                  SizedBox(
                    width: 28,
                    child: Text('${session.size.round()}'),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}
