import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../../core/image_utils.dart';

/// Mot layer dat tren anh: anh khac hoac sticker. Toa do tinh theo pixel anh nen.
class LayerItem {
  LayerItem.image(ui.Image img, {required this.center, required this.width})
      : image = img,
        emoji = null;
  LayerItem.sticker(String e, {required this.center, required this.width})
      : image = null,
        emoji = e;

  ui.Image? image;
  final String? emoji;
  Offset center;

  /// Chieu rong hien thi (pixel anh nen).
  double width;
  double rotation = 0;
  double opacity = 1;
  bool flipped = false;
  bool flippedV = false;
  bool shadow = false;

  /// He so keo gian chieu cao (1 = dung ti le goc).
  double stretch = 1;

  String get label => emoji ?? 'Ảnh';

  /// Ban sao doc lap (anh duoc clone) de luu vao lich su thao tac.
  LayerItem copy() {
    final img = image;
    final LayerItem c = img != null
        ? LayerItem.image(img.clone(), center: center, width: width)
        : LayerItem.sticker(emoji ?? '', center: center, width: width);
    c.rotation = rotation;
    c.opacity = opacity;
    c.flipped = flipped;
    c.flippedV = flippedV;
    c.shadow = shadow;
    c.stretch = stretch;
    return c;
  }
}

class LayerSession extends ChangeNotifier {
  final List<LayerItem> items = [];
  int selectedIndex = -1;
  Size imageSize = Size.zero;

  /// Vi tri duong giong dang bat dinh (giua anh hoac mep anh), null = khong.
  double? guideX;
  double? guideY;

  // --- Lich su thao tac trong cong cu Layer ---
  final List<List<LayerItem>> _states = [];
  final List<List<LayerItem>> _redo = [];
  bool _dirty = false;

  bool get canUndoStep => _states.length > 1;
  bool get canRedoStep => _redo.isNotEmpty;

  static void _disposeList(List<LayerItem> list) {
    for (final it in list) {
      it.image?.dispose();
    }
  }

  static List<LayerItem> _copyList(List<LayerItem> list) =>
      [for (final it in list) it.copy()];

  /// Ghi lai trang thai hien tai thanh mot buoc co the Undo.
  void commit() {
    _states.add(_copyList(items));
    for (final r in _redo) {
      _disposeList(r);
    }
    _redo.clear();
    while (_states.length > 20) {
      _disposeList(_states.removeAt(1));
    }
    _dirty = false;
    notifyListeners();
  }

  void commitIfDirty() {
    if (_dirty) commit();
  }

  /// Sua layer dang chon va ghi thanh mot buoc.
  void change(void Function(LayerItem item) fn) {
    if (selected == null) return;
    update(fn);
    commit();
  }

  void _restore(List<LayerItem> state) {
    _disposeList(items);
    items
      ..clear()
      ..addAll(_copyList(state));
    if (items.isEmpty) {
      selectedIndex = -1;
    } else if (selectedIndex < 0 || selectedIndex >= items.length) {
      selectedIndex = items.length - 1;
    }
    _dirty = false;
    notifyListeners();
  }

  void undoStep() {
    if (!canUndoStep) return;
    _redo.add(_states.removeLast());
    _restore(_states.last);
  }

  void redoStep() {
    if (_redo.isEmpty) return;
    final st = _redo.removeLast();
    _states.add(st);
    _restore(st);
  }

  /// Cac buoc gan nhat (toi da [max]) de dua vao lich su chinh khi xac nhan.
  List<List<LayerItem>> stepsForBake(int max) {
    commitIfDirty();
    final snaps = _states.where((st) => st.isNotEmpty).toList();
    return snaps.length > max ? snaps.sublist(snaps.length - max) : snaps;
  }

  Future<ui.Image> bakeState(ui.Image src, List<LayerItem> state) {
    return renderImage(src.width, src.height, (c) {
      c.drawImage(src, Offset.zero, Paint());
      c.clipRect(
          Rect.fromLTWH(0, 0, src.width.toDouble(), src.height.toDouble()));
      paintAll(c, state);
    });
  }

  LayerItem? get selected =>
      selectedIndex >= 0 && selectedIndex < items.length
          ? items[selectedIndex]
          : null;

  double get minWidth => math.max(8.0, imageSize.shortestSide * 0.04);
  double get maxWidth => math.max(16.0, imageSize.longestSide * 1.5);

  void begin(Size size) {
    clear();
    imageSize = size;
    _states.add(<LayerItem>[]);
    notifyListeners();
  }

  void clear() {
    for (final it in items) {
      it.image?.dispose();
    }
    items.clear();
    for (final st in _states) {
      _disposeList(st);
    }
    _states.clear();
    for (final st in _redo) {
      _disposeList(st);
    }
    _redo.clear();
    _dirty = false;
    selectedIndex = -1;
    guideX = null;
    guideY = null;
  }

  Offset get middle => Offset(imageSize.width / 2, imageSize.height / 2);

  void addImage(ui.Image img) {
    // Vua trong anh nen: toi da 50% chieu rong va 60% chieu cao.
    final double aspect = img.width / img.height;
    double w = imageSize.width * 0.5;
    if (w / aspect > imageSize.height * 0.6) {
      w = imageSize.height * 0.6 * aspect;
    }
    items.add(LayerItem.image(img, center: middle, width: w));
    selectedIndex = items.length - 1;
    commit();
  }

  void addSticker(String emoji) {
    items.add(LayerItem.sticker(emoji,
        center: middle, width: imageSize.shortestSide / 4));
    selectedIndex = items.length - 1;
    commit();
  }

  /// Thay anh cua mot layer (dung cho Thay the va Xoa nen).
  void replaceImage(LayerItem item, ui.Image img) {
    item.image?.dispose();
    item.image = img;
    commit();
  }

  void select(int i) {
    selectedIndex = i;
    notifyListeners();
  }

  void update(void Function(LayerItem item) change) {
    final it = selected;
    if (it == null) return;
    change(it);
    it.width = it.width.clamp(minWidth, maxWidth).toDouble();
    it.stretch = it.stretch.clamp(0.1, 10.0).toDouble();
    _dirty = true;
    notifyListeners();
  }

  void setGuides(double? x, double? y) {
    if (guideX == x && guideY == y) return;
    guideX = x;
    guideY = y;
    notifyListeners();
  }

  void removeSelected() {
    final it = selected;
    if (it == null) return;
    it.image?.dispose();
    items.removeAt(selectedIndex);
    selectedIndex = items.isEmpty ? -1 : items.length - 1;
    commit();
  }

  /// Doi thu tu layer: delta = 1 dua len tren, -1 dua xuong duoi.
  void move(int delta) {
    final int i = selectedIndex, j = i + delta;
    if (i < 0 || j < 0 || j >= items.length) return;
    final t = items[i];
    items[i] = items[j];
    items[j] = t;
    selectedIndex = j;
    commit();
  }

  TextPainter _emojiPainter(LayerItem it) {
    return TextPainter(
      text: TextSpan(
        text: it.emoji,
        style: TextStyle(
          fontSize: it.width * 0.8,
          height: 1.15,
          color: Colors.white.withOpacity(it.opacity),
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
  }

  Size sizeOf(LayerItem it) {
    final img = it.image;
    if (img != null) {
      return Size(
          it.width, it.width * img.height / img.width * it.stretch);
    }
    final tp = _emojiPainter(it);
    return Size(tp.width, tp.height);
  }

  /// Vi tri nut dieu khien: 0 = xoa (tren trai), 1 = xoay (tren phai),
  /// 2 = phong to (duoi phai), 3 = canh phai, 4 = canh trai,
  /// 5 = canh tren, 6 = canh duoi (4 nut canh de keo gian).
  Offset handlePos(LayerItem it, int which) {
    final s = sizeOf(it);
    final double hw = s.width / 2, hh = s.height / 2;
    double lx, ly;
    switch (which) {
      case 0:
        lx = -hw;
        ly = -hh;
        break;
      case 1:
        lx = hw;
        ly = -hh;
        break;
      case 2:
        lx = hw;
        ly = hh;
        break;
      case 3:
        lx = hw;
        ly = 0;
        break;
      case 4:
        lx = -hw;
        ly = 0;
        break;
      case 5:
        lx = 0;
        ly = -hh;
        break;
      default:
        lx = 0;
        ly = hh;
    }
    final c = math.cos(it.rotation), sn = math.sin(it.rotation);
    return it.center + Offset(lx * c - ly * sn, lx * sn + ly * c);
  }

  void paintAll(Canvas canvas, [List<LayerItem>? list]) {
    for (final it in list ?? items) {
      final s = sizeOf(it);
      canvas.save();
      canvas.translate(it.center.dx, it.center.dy);
      canvas.rotate(it.rotation);
      canvas.scale(it.flipped ? -1 : 1, it.flippedV ? -1 : 1);
      final img = it.image;
      if (img != null) {
        final srcRect =
            Rect.fromLTWH(0, 0, img.width.toDouble(), img.height.toDouble());
        final dst = Rect.fromCenter(
            center: Offset.zero, width: s.width, height: s.height);
        if (it.shadow) {
          final double off = s.width * 0.03, sigma = s.width * 0.02;
          canvas.drawImageRect(
            img,
            srcRect,
            dst.shift(Offset(off, off)),
            Paint()
              ..colorFilter = ColorFilter.mode(
                  Color.fromRGBO(0, 0, 0, 0.6 * it.opacity), BlendMode.srcIn)
              ..imageFilter = ui.ImageFilter.blur(
                  sigmaX: sigma, sigmaY: sigma, tileMode: TileMode.decal),
          );
        }
        canvas.drawImageRect(
          img,
          srcRect,
          dst,
          Paint()
            ..filterQuality = FilterQuality.medium
            ..color = Color.fromRGBO(0, 0, 0, it.opacity),
        );
      } else {
        _emojiPainter(it).paint(canvas, Offset(-s.width / 2, -s.height / 2));
      }
      canvas.restore();
    }
  }

  int hitTest(Offset p) {
    for (int i = items.length - 1; i >= 0; i--) {
      final it = items[i];
      final s = sizeOf(it);
      final d = p - it.center;
      final c = math.cos(-it.rotation), sn = math.sin(-it.rotation);
      final x = d.dx * c - d.dy * sn, y = d.dx * sn + d.dy * c;
      if (x.abs() <= s.width / 2 && y.abs() <= s.height / 2) return i;
    }
    return -1;
  }

  Future<ui.Image> bake(ui.Image src) {
    return renderImage(src.width, src.height, (c) {
      c.drawImage(src, Offset.zero, Paint());
      c.clipRect(
          Rect.fromLTWH(0, 0, src.width.toDouble(), src.height.toDouble()));
      paintAll(c);
    });
  }

  @override
  void dispose() {
    clear();
    super.dispose();
  }
}

enum _Drag { move, rotate, scale, stretchX, stretchY }

/// Vung lam viec cua cong cu Layer. Chiem ca khoang trong quanh anh
/// de cac nut dieu khien nam ngoai mep anh van bam duoc.
/// - cham de chon, keo de di chuyen (tu bat dinh vao giua anh),
/// - nut X de xoa, nut xoay, nut phong to o cac goc,
/// - 2 ngon de phong to/thu nho va xoay.
class LayerStage extends StatefulWidget {
  const LayerStage({super.key, required this.image, required this.session});

  final ui.Image image;
  final LayerSession session;

  @override
  State<LayerStage> createState() => _LayerStageState();
}

class _LayerStageState extends State<LayerStage> {
  _Drag _mode = _Drag.move;
  double _baseWidth = 0;
  double _baseRotation = 0;
  double _startAngle = 0;
  double _startDist = 1;
  double _baseHeight = 0;
  Offset _free = Offset.zero;
  double _scale = 1;
  Offset _origin = Offset.zero;

  LayerSession get s => widget.session;

  Offset _toImage(Offset local) => (local - _origin) / _scale;

  int _handleAt(LayerItem it, Offset p) {
    int best = -1;
    double bestDist = 30 / _scale;
    final int count = it.image != null ? 7 : 3;
    for (int h = 0; h < count; h++) {
      final d = (s.handlePos(it, h) - p).distance;
      if (d < bestDist) {
        bestDist = d;
        best = h;
      }
    }
    return best;
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        const double pad = 30;
        final double w = constraints.maxWidth, h = constraints.maxHeight;
        final double iw = widget.image.width.toDouble();
        final double ih = widget.image.height.toDouble();
        _scale = math.min(
            math.max(1.0, w - pad * 2) / iw, math.max(1.0, h - pad * 2) / ih);
        _origin = Offset((w - iw * _scale) / 2, (h - ih * _scale) / 2);

        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapUp: (d) {
            final p = _toImage(d.localPosition);
            final it = s.selected;
            if (it != null && _handleAt(it, p) == 0) {
              s.removeSelected();
            } else {
              s.select(s.hitTest(p));
            }
          },
          onScaleStart: (d) {
            final p = _toImage(d.localFocalPoint);
            _mode = _Drag.move;
            var it = s.selected;
            if (it != null && d.pointerCount == 1) {
              final h = _handleAt(it, p);
              if (h == 1) _mode = _Drag.rotate;
              if (h == 2) _mode = _Drag.scale;
              if (h == 3 || h == 4) _mode = _Drag.stretchX;
              if (h == 5 || h == 6) _mode = _Drag.stretchY;
            }
            if (_mode == _Drag.move && d.pointerCount == 1) {
              final hit = s.hitTest(p);
              if (hit >= 0 && hit != s.selectedIndex) s.select(hit);
              it = s.selected;
            }
            if (it != null) {
              final v = p - it.center;
              _baseWidth = it.width;
              _baseRotation = it.rotation;
              _baseHeight = s.sizeOf(it).height;
              _startAngle = math.atan2(v.dy, v.dx);
              _startDist = math.max(1.0, v.distance);
              _free = it.center;
            }
          },
          onScaleUpdate: (d) {
            final p = _toImage(d.localFocalPoint);
            double? gx, gy;
            s.update((it) {
              final v = p - it.center;
              // Toa do diem cham trong he truc cua layer (bo goc xoay).
              final double cr = math.cos(-it.rotation);
              final double sr = math.sin(-it.rotation);
              final double localX = v.dx * cr - v.dy * sr;
              final double localY = v.dx * sr + v.dy * cr;
              final img = it.image;
              final double nat = img == null ? 1 : img.height / img.width;
              switch (_mode) {
                case _Drag.stretchX:
                  // Keo canh trai/phai: doi chieu rong, giu nguyen chieu cao.
                  it.width = (2 * localX.abs())
                      .clamp(s.minWidth, s.maxWidth)
                      .toDouble();
                  it.stretch = _baseHeight / (it.width * nat);
                  break;
                case _Drag.stretchY:
                  // Keo canh tren/duoi: doi chieu cao, giu nguyen chieu rong.
                  it.stretch = math.max(8 / _scale, 2 * localY.abs()) /
                      (it.width * nat);
                  break;
                case _Drag.rotate:
                  it.rotation =
                      _baseRotation + math.atan2(v.dy, v.dx) - _startAngle;
                  break;
                case _Drag.scale:
                  it.width = _baseWidth * v.distance / _startDist;
                  break;
                case _Drag.move:
                  _free += d.focalPointDelta / _scale;
                  double x = _free.dx.clamp(0.0, s.imageSize.width).toDouble();
                  double y =
                      _free.dy.clamp(0.0, s.imageSize.height).toDouble();
                  final double th = 8 / _scale;
                  final mid = s.middle;
                  // Nua be rong/cao cua khung bao layer (tinh ca goc xoay).
                  final sz = s.sizeOf(it);
                  final double ca = math.cos(it.rotation).abs();
                  final double sa = math.sin(it.rotation).abs();
                  final double hx = sz.width / 2 * ca + sz.height / 2 * sa;
                  final double hy = sz.width / 2 * sa + sz.height / 2 * ca;
                  final double iw = s.imageSize.width;
                  final double ih = s.imageSize.height;
                  // Bat dinh: tam vao giua anh, mep layer vao mep anh.
                  if ((x - mid.dx).abs() < th) {
                    x = mid.dx;
                    gx = mid.dx;
                  } else if ((x - hx).abs() < th) {
                    x = hx;
                    gx = 0;
                  } else if ((x + hx - iw).abs() < th) {
                    x = iw - hx;
                    gx = iw;
                  }
                  if ((y - mid.dy).abs() < th) {
                    y = mid.dy;
                    gy = mid.dy;
                  } else if ((y - hy).abs() < th) {
                    y = hy;
                    gy = 0;
                  } else if ((y + hy - ih).abs() < th) {
                    y = ih - hy;
                    gy = ih;
                  }
                  it.center = Offset(x, y);
                  if (d.pointerCount >= 2 && _baseWidth > 0) {
                    it.width = _baseWidth * d.scale;
                    it.rotation = _baseRotation + d.rotation;
                  }
                  break;
              }
            });
            s.setGuides(gx, gy);
          },
          onScaleEnd: (_) {
            s.setGuides(null, null);
            s.commitIfDirty();
          },
          child: CustomPaint(
            size: Size(w, h),
            painter: _LayerPainter(s, widget.image, _scale, _origin),
          ),
        );
      },
    );
  }
}

class _LayerPainter extends CustomPainter {
  _LayerPainter(this.session, this.base, this.scale, this.origin)
      : super(repaint: session);

  final LayerSession session;
  final ui.Image base;
  final double scale;
  final Offset origin;

  @override
  void paint(Canvas canvas, Size size) {
    final bounds =
        Rect.fromLTWH(0, 0, base.width.toDouble(), base.height.toDouble());
    canvas.save();
    canvas.translate(origin.dx, origin.dy);
    canvas.scale(scale);

    // Anh nen + cac layer. Khi dang sua, phan layer nam ngoai anh van hien
    // de de thao tac; khi xac nhan thi phan ngoai anh se bi cat.
    canvas.drawImageRect(
        base, bounds, bounds, Paint()..filterQuality = FilterQuality.medium);
    session.paintAll(canvas);

    final double px = 1 / scale;

    // Duong giong khi layer nam dung giua.
    final guide = Paint()
      ..color = const Color(0xFF5CE1C6)
      ..strokeWidth = 1.2 * px;
    final double? gx = session.guideX, gy = session.guideY;
    if (gx != null) {
      canvas.drawLine(Offset(gx, 0), Offset(gx, bounds.height), guide);
    }
    if (gy != null) {
      canvas.drawLine(Offset(0, gy), Offset(bounds.width, gy), guide);
    }

    final it = session.selected;
    if (it != null) {
      final s = session.sizeOf(it);
      canvas.save();
      canvas.translate(it.center.dx, it.center.dy);
      canvas.rotate(it.rotation);
      canvas.drawRect(
        Rect.fromCenter(center: Offset.zero, width: s.width, height: s.height),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5 * px
          ..color = Colors.white,
      );
      canvas.restore();

      final fill = Paint()..color = Colors.white;
      final ring = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1 * px
        ..color = Colors.black26;
      final ink = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.8 * px
        ..strokeCap = StrokeCap.round
        ..color = Colors.black87;
      final double r = 13 * px, g = 4.5 * px;
      // 4 cham giua canh de keo gian (chi voi layer anh).
      if (it.image != null) {
        for (int h = 3; h < 7; h++) {
          final c = session.handlePos(it, h);
          canvas.drawCircle(c, 6 * px, fill);
          canvas.drawCircle(c, 6 * px, ring);
        }
      }
      for (int h = 0; h < 3; h++) {
        final c = session.handlePos(it, h);
        canvas.drawCircle(c, r, fill);
        canvas.drawCircle(c, r, ring);
        if (h == 0) {
          canvas.drawLine(c + Offset(-g, -g), c + Offset(g, g), ink);
          canvas.drawLine(c + Offset(-g, g), c + Offset(g, -g), ink);
        } else if (h == 1) {
          canvas.drawArc(Rect.fromCircle(center: c, radius: g * 1.2), -2.4,
              4.6, false, ink);
          canvas.drawLine(c + Offset(g * 1.3, -g * 0.2),
              c + Offset(g * 0.5, g * 0.9), ink);
        } else {
          canvas.drawLine(c + Offset(-g, -g), c + Offset(g, g), ink);
          canvas.drawLine(c + Offset(g, g), c + Offset(g * 0.1, g), ink);
          canvas.drawLine(c + Offset(g, g), c + Offset(g, g * 0.1), ink);
          canvas.drawLine(c + Offset(-g, -g), c + Offset(-g * 0.1, -g), ink);
          canvas.drawLine(c + Offset(-g, -g), c + Offset(-g, -g * 0.1), ink);
        }
      }
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _LayerPainter oldDelegate) => true;
}
