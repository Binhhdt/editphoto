import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../../core/app_config.dart';
import '../../core/image_utils.dart';

/// Mot layer dat tren anh: anh khac hoac sticker. Toa do tinh theo pixel anh nen.
class LayerItem {
  LayerItem.image(ui.Image img, {required this.center, required this.width})
      : image = img,
        emoji = null;
  LayerItem.sticker(String e, {required this.center, required this.width})
      : image = null,
        emoji = e;

  final ui.Image? image;
  final String? emoji;
  Offset center;

  /// Chieu rong hien thi (pixel anh nen).
  double width;
  double rotation = 0;
  double opacity = 1;
  bool flipped = false;

  String get label => emoji ?? 'Ảnh';
}

class LayerSession extends ChangeNotifier {
  final List<LayerItem> items = [];
  int selectedIndex = -1;
  Size imageSize = Size.zero;

  LayerItem? get selected =>
      selectedIndex >= 0 && selectedIndex < items.length
          ? items[selectedIndex]
          : null;

  double get minWidth => math.max(8.0, imageSize.shortestSide * 0.04);
  double get maxWidth => math.max(16.0, imageSize.longestSide * 1.5);

  void begin(Size size) {
    clear();
    imageSize = size;
    notifyListeners();
  }

  void clear() {
    for (final it in items) {
      it.image?.dispose();
    }
    items.clear();
    selectedIndex = -1;
  }

  Offset get _middle => Offset(imageSize.width / 2, imageSize.height / 2);

  void addImage(ui.Image img) {
    items.add(LayerItem.image(img,
        center: _middle, width: imageSize.width * 0.6));
    selectedIndex = items.length - 1;
    notifyListeners();
  }

  void addSticker(String emoji) {
    items.add(LayerItem.sticker(emoji,
        center: _middle, width: imageSize.shortestSide / 4));
    selectedIndex = items.length - 1;
    notifyListeners();
  }

  void select(int i) {
    selectedIndex = i;
    notifyListeners();
  }

  void update(void Function(LayerItem item) change) {
    final it = selected;
    if (it == null) return;
    change(it);
    it.width = it.width.clamp(minWidth, maxWidth).toDouble();
    notifyListeners();
  }

  void removeSelected() {
    final it = selected;
    if (it == null) return;
    it.image?.dispose();
    items.removeAt(selectedIndex);
    selectedIndex = items.isEmpty ? -1 : items.length - 1;
    notifyListeners();
  }

  /// Doi thu tu layer: delta = 1 dua len tren, -1 dua xuong duoi.
  void move(int delta) {
    final int i = selectedIndex, j = i + delta;
    if (i < 0 || j < 0 || j >= items.length) return;
    final t = items[i];
    items[i] = items[j];
    items[j] = t;
    selectedIndex = j;
    notifyListeners();
  }

  TextPainter _emojiPainter(LayerItem it) {
    return TextPainter(
      text: TextSpan(
        text: it.emoji,
        style: TextStyle(
          fontSize: it.width * 0.8,
          height: 1.15,
          color: Colors.white.withOpacity(it.opacity),
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
  }

  Size sizeOf(LayerItem it) {
    final img = it.image;
    if (img != null) {
      return Size(it.width, it.width * img.height / img.width);
    }
    final tp = _emojiPainter(it);
    return Size(tp.width, tp.height);
  }

  void paintAll(Canvas canvas) {
    for (final it in items) {
      final s = sizeOf(it);
      canvas.save();
      canvas.translate(it.center.dx, it.center.dy);
      canvas.rotate(it.rotation);
      if (it.flipped) canvas.scale(-1, 1);
      final img = it.image;
      if (img != null) {
        canvas.drawImageRect(
          img,
          Rect.fromLTWH(0, 0, img.width.toDouble(), img.height.toDouble()),
          Rect.fromCenter(
              center: Offset.zero, width: s.width, height: s.height),
          Paint()
            ..filterQuality = FilterQuality.medium
            ..color = Color.fromRGBO(0, 0, 0, it.opacity),
        );
      } else {
        _emojiPainter(it).paint(canvas, Offset(-s.width / 2, -s.height / 2));
      }
      canvas.restore();
    }
  }

  int hitTest(Offset p) {
    for (int i = items.length - 1; i >= 0; i--) {
      final it = items[i];
      final s = sizeOf(it);
      final d = p - it.center;
      final c = math.cos(-it.rotation), sn = math.sin(-it.rotation);
      final x = d.dx * c - d.dy * sn, y = d.dx * sn + d.dy * c;
      if (x.abs() <= s.width / 2 && y.abs() <= s.height / 2) return i;
    }
    return -1;
  }

  Future<ui.Image> bake(ui.Image src) {
    return renderImage(src.width, src.height, (c) {
      c.drawImage(src, Offset.zero, Paint());
      c.clipRect(
          Rect.fromLTWH(0, 0, src.width.toDouble(), src.height.toDouble()));
      paintAll(c);
    });
  }

  @override
  void dispose() {
    clear();
    super.dispose();
  }
}

/// Hien thi va thao tac layer: cham de chon, keo de di chuyen,
/// 2 ngon de phong to/thu nho va xoay.
class LayerView extends StatefulWidget {
  const LayerView({super.key, required this.session, required this.scale});

  final LayerSession session;
  final double scale;

  @override
  State<LayerView> createState() => _LayerViewState();
}

class _LayerViewState extends State<LayerView> {
  double _baseWidth = 0;
  double _baseRotation = 0;

  LayerSession get s => widget.session;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapUp: (d) => s.select(s.hitTest(d.localPosition / widget.scale)),
      onScaleStart: (d) {
        final hit = s.hitTest(d.localFocalPoint / widget.scale);
        if (hit >= 0 && hit != s.selectedIndex) s.select(hit);
        final it = s.selected;
        if (it != null) {
          _baseWidth = it.width;
          _baseRotation = it.rotation;
        }
      },
      onScaleUpdate: (d) {
        s.update((it) {
          final moved = it.center + d.focalPointDelta / widget.scale;
          it.center = Offset(
            moved.dx.clamp(0.0, s.imageSize.width).toDouble(),
            moved.dy.clamp(0.0, s.imageSize.height).toDouble(),
          );
          if (d.pointerCount >= 2 && _baseWidth > 0) {
            it.width = _baseWidth * d.scale;
            it.rotation = _baseRotation + d.rotation;
          }
        });
      },
      child: ClipRect(
        child: CustomPaint(
          painter: _LayerPainter(s, widget.scale),
          size: Size.infinite,
        ),
      ),
    );
  }
}

class _LayerPainter extends CustomPainter {
  _LayerPainter(this.session, this.scale) : super(repaint: session);

  final LayerSession session;
  final double scale;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(scale);
    session.paintAll(canvas);
    final it = session.selected;
    if (it != null) {
      final s = session.sizeOf(it);
      canvas.translate(it.center.dx, it.center.dy);
      canvas.rotate(it.rotation);
      canvas.drawRect(
        Rect.fromCenter(center: Offset.zero, width: s.width, height: s.height),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5 / scale
          ..color = AppColors.accent,
      );
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _LayerPainter oldDelegate) =>
      oldDelegate.scale != scale || oldDelegate.session != session;
}
