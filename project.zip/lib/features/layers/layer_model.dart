import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../../core/image_utils.dart';

/// Mot layer dat tren anh: anh khac hoac sticker. Toa do tinh theo pixel anh nen.
class LayerItem {
  LayerItem.image(ui.Image img, {required this.center, required this.width})
      : image = img,
        emoji = null;
  LayerItem.sticker(String e, {required this.center, required this.width})
      : image = null,
        emoji = e;

  ui.Image? image;
  final String? emoji;
  Offset center;

  /// Chieu rong hien thi (pixel anh nen).
  double width;
  double rotation = 0;
  double opacity = 1;
  bool flipped = false;
  bool flippedV = false;
  bool shadow = false;

  String get label => emoji ?? 'Ảnh';
}

class LayerSession extends ChangeNotifier {
  final List<LayerItem> items = [];
  int selectedIndex = -1;
  Size imageSize = Size.zero;

  /// Dang bat dinh vao truc giua (de ve duong giong).
  bool snapX = false;
  bool snapY = false;

  LayerItem? get selected =>
      selectedIndex >= 0 && selectedIndex < items.length
          ? items[selectedIndex]
          : null;

  double get minWidth => math.max(8.0, imageSize.shortestSide * 0.04);
  double get maxWidth => math.max(16.0, imageSize.longestSide * 1.5);

  void begin(Size size) {
    clear();
    imageSize = size;
    notifyListeners();
  }

  void clear() {
    for (final it in items) {
      it.image?.dispose();
    }
    items.clear();
    selectedIndex = -1;
    snapX = false;
    snapY = false;
  }

  Offset get middle => Offset(imageSize.width / 2, imageSize.height / 2);

  void addImage(ui.Image img) {
    items.add(
        LayerItem.image(img, center: middle, width: imageSize.width * 0.5));
    selectedIndex = items.length - 1;
    notifyListeners();
  }

  void addSticker(String emoji) {
    items.add(LayerItem.sticker(emoji,
        center: middle, width: imageSize.shortestSide / 4));
    selectedIndex = items.length - 1;
    notifyListeners();
  }

  /// Thay anh cua mot layer (dung cho Thay the va Xoa nen).
  void replaceImage(LayerItem item, ui.Image img) {
    item.image?.dispose();
    item.image = img;
    notifyListeners();
  }

  void select(int i) {
    selectedIndex = i;
    notifyListeners();
  }

  void update(void Function(LayerItem item) change) {
    final it = selected;
    if (it == null) return;
    change(it);
    it.width = it.width.clamp(minWidth, maxWidth).toDouble();
    notifyListeners();
  }

  void setSnap(bool x, bool y) {
    if (snapX == x && snapY == y) return;
    snapX = x;
    snapY = y;
    notifyListeners();
  }

  void removeSelected() {
    final it = selected;
    if (it == null) return;
    it.image?.dispose();
    items.removeAt(selectedIndex);
    selectedIndex = items.isEmpty ? -1 : items.length - 1;
    notifyListeners();
  }

  /// Doi thu tu layer: delta = 1 dua len tren, -1 dua xuong duoi.
  void move(int delta) {
    final int i = selectedIndex, j = i + delta;
    if (i < 0 || j < 0 || j >= items.length) return;
    final t = items[i];
    items[i] = items[j];
    items[j] = t;
    selectedIndex = j;
    notifyListeners();
  }

  TextPainter _emojiPainter(LayerItem it) {
    return TextPainter(
      text: TextSpan(
        text: it.emoji,
        style: TextStyle(
          fontSize: it.width * 0.8,
          height: 1.15,
          color: Colors.white.withOpacity(it.opacity),
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
  }

  Size sizeOf(LayerItem it) {
    final img = it.image;
    if (img != null) {
      return Size(it.width, it.width * img.height / img.width);
    }
    final tp = _emojiPainter(it);
    return Size(tp.width, tp.height);
  }

  /// Vi tri nut dieu khien: 0 = xoa (tren trai), 1 = xoay (tren phai),
  /// 2 = phong to (duoi phai).
  Offset handlePos(LayerItem it, int which) {
    final s = sizeOf(it);
    final double lx = which == 0 ? -s.width / 2 : s.width / 2;
    final double ly = which == 2 ? s.height / 2 : -s.height / 2;
    final c = math.cos(it.rotation), sn = math.sin(it.rotation);
    return it.center + Offset(lx * c - ly * sn, lx * sn + ly * c);
  }

  void paintAll(Canvas canvas) {
    for (final it in items) {
      final s = sizeOf(it);
      canvas.save();
      canvas.translate(it.center.dx, it.center.dy);
      canvas.rotate(it.rotation);
      canvas.scale(it.flipped ? -1 : 1, it.flippedV ? -1 : 1);
      final img = it.image;
      if (img != null) {
        final srcRect =
            Rect.fromLTWH(0, 0, img.width.toDouble(), img.height.toDouble());
        final dst = Rect.fromCenter(
            center: Offset.zero, width: s.width, height: s.height);
        if (it.shadow) {
          final double off = s.width * 0.03, sigma = s.width * 0.02;
          canvas.drawImageRect(
            img,
            srcRect,
            dst.shift(Offset(off, off)),
            Paint()
              ..colorFilter = ColorFilter.mode(
                  Color.fromRGBO(0, 0, 0, 0.6 * it.opacity), BlendMode.srcIn)
              ..imageFilter = ui.ImageFilter.blur(
                  sigmaX: sigma, sigmaY: sigma, tileMode: TileMode.decal),
          );
        }
        canvas.drawImageRect(
          img,
          srcRect,
          dst,
          Paint()
            ..filterQuality = FilterQuality.medium
            ..color = Color.fromRGBO(0, 0, 0, it.opacity),
        );
      } else {
        _emojiPainter(it).paint(canvas, Offset(-s.width / 2, -s.height / 2));
      }
      canvas.restore();
    }
  }

  int hitTest(Offset p) {
    for (int i = items.length - 1; i >= 0; i--) {
      final it = items[i];
      final s = sizeOf(it);
      final d = p - it.center;
      final c = math.cos(-it.rotation), sn = math.sin(-it.rotation);
      final x = d.dx * c - d.dy * sn, y = d.dx * sn + d.dy * c;
      if (x.abs() <= s.width / 2 && y.abs() <= s.height / 2) return i;
    }
    return -1;
  }

  Future<ui.Image> bake(ui.Image src) {
    return renderImage(src.width, src.height, (c) {
      c.drawImage(src, Offset.zero, Paint());
      c.clipRect(
          Rect.fromLTWH(0, 0, src.width.toDouble(), src.height.toDouble()));
      paintAll(c);
    });
  }

  @override
  void dispose() {
    clear();
    super.dispose();
  }
}

enum _Drag { move, rotate, scale }

/// Hien thi va thao tac layer:
/// - cham de chon, keo de di chuyen (tu bat dinh vao giua anh),
/// - nut X de xoa, nut xoay, nut phong to o cac goc,
/// - 2 ngon de phong to/thu nho va xoay.
class LayerView extends StatefulWidget {
  const LayerView({super.key, required this.session, required this.scale});

  final LayerSession session;
  final double scale;

  @override
  State<LayerView> createState() => _LayerViewState();
}

class _LayerViewState extends State<LayerView> {
  _Drag _mode = _Drag.move;
  double _baseWidth = 0;
  double _baseRotation = 0;
  double _startAngle = 0;
  double _startDist = 1;
  Offset _free = Offset.zero;

  LayerSession get s => widget.session;

  bool _near(LayerItem it, int which, Offset p) =>
      (s.handlePos(it, which) - p).distance < 26 / widget.scale;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapUp: (d) {
        final p = d.localPosition / widget.scale;
        final it = s.selected;
        if (it != null && _near(it, 0, p)) {
          s.removeSelected();
        } else {
          s.select(s.hitTest(p));
        }
      },
      onScaleStart: (d) {
        final p = d.localFocalPoint / widget.scale;
        _mode = _Drag.move;
        var it = s.selected;
        if (it != null && d.pointerCount == 1) {
          if (_near(it, 1, p)) {
            _mode = _Drag.rotate;
          } else if (_near(it, 2, p)) {
            _mode = _Drag.scale;
          }
        }
        if (_mode == _Drag.move) {
          final hit = s.hitTest(p);
          if (hit >= 0 && hit != s.selectedIndex) s.select(hit);
          it = s.selected;
        }
        if (it != null) {
          final v = p - it.center;
          _baseWidth = it.width;
          _baseRotation = it.rotation;
          _startAngle = math.atan2(v.dy, v.dx);
          _startDist = math.max(1.0, v.distance);
          _free = it.center;
        }
      },
      onScaleUpdate: (d) {
        final p = d.localFocalPoint / widget.scale;
        bool sx = false, sy = false;
        s.update((it) {
          final v = p - it.center;
          switch (_mode) {
            case _Drag.rotate:
              it.rotation =
                  _baseRotation + math.atan2(v.dy, v.dx) - _startAngle;
              break;
            case _Drag.scale:
              it.width = _baseWidth * v.distance / _startDist;
              break;
            case _Drag.move:
              _free += d.focalPointDelta / widget.scale;
              double x = _free.dx.clamp(0.0, s.imageSize.width).toDouble();
              double y = _free.dy.clamp(0.0, s.imageSize.height).toDouble();
              final double th = 8 / widget.scale;
              final mid = s.middle;
              if ((x - mid.dx).abs() < th) {
                x = mid.dx;
                sx = true;
              }
              if ((y - mid.dy).abs() < th) {
                y = mid.dy;
                sy = true;
              }
              it.center = Offset(x, y);
              if (d.pointerCount >= 2 && _baseWidth > 0) {
                it.width = _baseWidth * d.scale;
                it.rotation = _baseRotation + d.rotation;
              }
              break;
          }
        });
        s.setSnap(sx, sy);
      },
      onScaleEnd: (_) => s.setSnap(false, false),
      child: CustomPaint(
        painter: _LayerPainter(s, widget.scale),
        size: Size.infinite,
      ),
    );
  }
}

class _LayerPainter extends CustomPainter {
  _LayerPainter(this.session, this.scale) : super(repaint: session);

  final LayerSession session;
  final double scale;

  @override
  void paint(Canvas canvas, Size size) {
    // Noi dung layer bi cat theo khung anh, giong ket qua cuoi.
    canvas.save();
    canvas.clipRect(Offset.zero & size);
    canvas.scale(scale);
    session.paintAll(canvas);
    canvas.restore();

    canvas.save();
    canvas.scale(scale);
    final double px = 1 / scale;

    // Duong giong khi layer nam dung giua.
    final guide = Paint()
      ..color = const Color(0xFF5CE1C6)
      ..strokeWidth = 1.2 * px;
    final mid = session.middle;
    if (session.snapX) {
      canvas.drawLine(
          Offset(mid.dx, 0), Offset(mid.dx, session.imageSize.height), guide);
    }
    if (session.snapY) {
      canvas.drawLine(
          Offset(0, mid.dy), Offset(session.imageSize.width, mid.dy), guide);
    }

    final it = session.selected;
    if (it != null) {
      final s = session.sizeOf(it);
      canvas.save();
      canvas.translate(it.center.dx, it.center.dy);
      canvas.rotate(it.rotation);
      canvas.drawRect(
        Rect.fromCenter(center: Offset.zero, width: s.width, height: s.height),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5 * px
          ..color = Colors.white,
      );
      canvas.restore();

      final fill = Paint()..color = Colors.white;
      final ring = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1 * px
        ..color = Colors.black26;
      final ink = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.8 * px
        ..strokeCap = StrokeCap.round
        ..color = Colors.black87;
      final double r = 12 * px, g = 4.5 * px;
      for (int h = 0; h < 3; h++) {
        final c = session.handlePos(it, h);
        canvas.drawCircle(c, r, fill);
        canvas.drawCircle(c, r, ring);
        if (h == 0) {
          canvas.drawLine(c + Offset(-g, -g), c + Offset(g, g), ink);
          canvas.drawLine(c + Offset(-g, g), c + Offset(g, -g), ink);
        } else if (h == 1) {
          canvas.drawArc(Rect.fromCircle(center: c, radius: g * 1.2), -2.4,
              4.6, false, ink);
          canvas.drawLine(c + Offset(g * 1.3, -g * 0.2),
              c + Offset(g * 0.5, g * 0.9), ink);
        } else {
          canvas.drawLine(c + Offset(-g, -g), c + Offset(g, g), ink);
          canvas.drawLine(c + Offset(g, g), c + Offset(g * 0.1, g), ink);
          canvas.drawLine(c + Offset(g, g), c + Offset(g, g * 0.1), ink);
          canvas.drawLine(c + Offset(-g, -g), c + Offset(-g * 0.1, -g), ink);
          canvas.drawLine(c + Offset(-g, -g), c + Offset(-g, -g * 0.1), ink);
        }
      }
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _LayerPainter oldDelegate) =>
      oldDelegate.scale != scale || oldDelegate.session != session;
}
