import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../../core/app_config.dart';
import '../../core/image_utils.dart';
import '../ai/segmentation_service.dart';
import '../editor/widgets/tool_button.dart';
import '../picker/image_picker_service.dart';
import 'layer_model.dart';

const List<String> kStickers = [
  '😀', '😂', '😍', '😎', '🥳', '😭', '😡', '🤔', '😴', '🤩', '😇', '🥰',
  '❤️', '💔', '💯', '🔥', '✨', '⭐', '🌈', '☀️', '🌙', '⚡', '💧', '❄️',
  '👍', '👏', '🙏', '💪', '✌️', '👀', '👑', '🎉', '🎁', '🎂', '🎈', '🏆',
  '🌸', '🌹', '🌻', '🍀', '🌴', '🐶', '🐱', '🦋', '🍕', '☕', '🍓', '🍦',
  '⚽', '🎵', '📷', '✈️', '🚗', '💬', '💤', '❗', '❓', '✅', '❌', '➡️',
];

Future<String?> showStickerSheet(BuildContext context) {
  return showModalBottomSheet<String>(
    context: context,
    backgroundColor: AppColors.panel,
    builder: (ctx) => SafeArea(
      child: SizedBox(
        height: 320,
        child: GridView.count(
          crossAxisCount: 6,
          padding: const EdgeInsets.all(12),
          children: [
            for (final e in kStickers)
              InkWell(
                onTap: () => Navigator.pop(ctx, e),
                child: Center(
                  child: Text(e, style: const TextStyle(fontSize: 30)),
                ),
              ),
          ],
        ),
      ),
    ),
  );
}

class LayerPanel extends StatefulWidget {
  const LayerPanel({super.key, required this.session});

  final LayerSession session;

  @override
  State<LayerPanel> createState() => _LayerPanelState();
}

class _LayerPanelState extends State<LayerPanel> {
  bool _working = false;

  LayerSession get s => widget.session;

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<ui.Image?> _pick() async {
    try {
      final bytes = await ImagePickerService.pickFromGallery();
      if (bytes == null) return null;
      return await decodeImage(bytes);
    } catch (e) {
      _snack('Không mở được ảnh: $e');
      return null;
    }
  }

  Future<void> _addImage() async {
    final img = await _pick();
    if (img != null) s.addImage(img);
  }

  Future<void> _replace() async {
    final it = s.selected;
    if (it == null || it.image == null) return;
    final img = await _pick();
    if (img == null) return;
    if (s.items.contains(it)) {
      s.replaceImage(it, img);
    } else {
      img.dispose();
    }
  }

  Future<void> _addSticker() async {
    final e = await showStickerSheet(context);
    if (e != null) s.addSticker(e);
  }

  /// AI xoa nen rieng cho layer dang chon.
  Future<void> _cutout() async {
    final it = s.selected;
    final img = it?.image;
    if (it == null || img == null || _working) return;
    setState(() => _working = true);
    try {
      final cut = await SegmentationService.cutout(img);
      if (s.items.contains(it)) {
        s.replaceImage(it, cut);
      } else {
        cut.dispose();
      }
    } catch (e) {
      final low = e.toString().toLowerCase();
      _snack(low.contains('download') || low.contains('module')
          ? 'Máy đang tải mô hình AI lần đầu (cần mạng). Hãy thử lại sau ít phút.'
          : 'Không xóa nền được: $e');
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (context, _) {
        final it = s.selected;
        final bool isImage = it?.image != null;
        final int i = s.selectedIndex, n = s.items.length;
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (_working) const LinearProgressIndicator(minHeight: 3),
            if (it == null)
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 12, 16, 4),
                child: Text(
                  'Thêm ảnh hoặc sticker. Kéo để di chuyển, kéo nút ở góc để xoay và phóng to.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12, color: Colors.white70),
                ),
              )
            else
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 12, top: 4),
                child: Row(
                  children: [
                    const Text('Độ mờ đục', style: TextStyle(fontSize: 12)),
                    Expanded(
                      child: Slider(
                        min: 0.05,
                        max: 1,
                        value: it.opacity.clamp(0.05, 1.0).toDouble(),
                        onChanged: (v) => s.update((x) => x.opacity = v),
                      ),
                    ),
                    SizedBox(
                      width: 30,
                      child: Text('${(it.opacity * 100).round()}'),
                    ),
                  ],
                ),
              ),
            SizedBox(
              height: 72,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 6),
                children: [
                  ToolButton(
                    icon: Icons.add_photo_alternate_outlined,
                    label: 'Thêm ảnh',
                    onTap: () => _addImage(),
                  ),
                  ToolButton(
                    icon: Icons.emoji_emotions_outlined,
                    label: 'Sticker',
                    onTap: () => _addSticker(),
                  ),
                  ToolButton(
                    icon: Icons.swap_horiz,
                    label: 'Thay thế',
                    onTap: isImage ? () => _replace() : null,
                  ),
                  ToolButton(
                    icon: Icons.auto_fix_high,
                    label: 'Xóa nền',
                    onTap: isImage && !_working ? () => _cutout() : null,
                  ),
                  ToolButton(
                    icon: Icons.flip,
                    label: 'Lật ngang',
                    onTap: it == null
                        ? null
                        : () => s.update((x) => x.flipped = !x.flipped),
                  ),
                  ToolButton(
                    icon: Icons.flip,
                    quarterTurns: 1,
                    label: 'Lật dọc',
                    onTap: it == null
                        ? null
                        : () => s.update((x) => x.flippedV = !x.flippedV),
                  ),
                  ToolButton(
                    icon: Icons.rotate_90_degrees_cw_outlined,
                    label: 'Xoay 90°',
                    onTap: it == null
                        ? null
                        : () => s.update((x) => x.rotation += math.pi / 2),
                  ),
                  ToolButton(
                    icon: Icons.layers_outlined,
                    label: 'Đổ bóng',
                    selected: it?.shadow ?? false,
                    onTap: isImage
                        ? () => s.update((x) => x.shadow = !x.shadow)
                        : null,
                  ),
                  ToolButton(
                    icon: Icons.flip_to_front,
                    label: 'Lên trên',
                    onTap: it != null && i < n - 1 ? () => s.move(1) : null,
                  ),
                  ToolButton(
                    icon: Icons.flip_to_back,
                    label: 'Xuống dưới',
                    onTap: it != null && i > 0 ? () => s.move(-1) : null,
                  ),
                  ToolButton(
                    icon: Icons.delete_outline,
                    label: 'Xóa',
                    onTap: it == null ? null : () => s.removeSelected(),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}
