import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../core/app_config.dart';
import '../../core/image_utils.dart';
import '../picker/image_picker_service.dart';
import 'layer_model.dart';

const List<String> kStickers = [
  '😀', '😂', '😍', '😎', '🥳', '😭', '😡', '🤔', '😴', '🤩', '😇', '🥰',
  '❤️', '💔', '💯', '🔥', '✨', '⭐', '🌈', '☀️', '🌙', '⚡', '💧', '❄️',
  '👍', '👏', '🙏', '💪', '✌️', '👀', '👑', '🎉', '🎁', '🎂', '🎈', '🏆',
  '🌸', '🌹', '🌻', '🍀', '🌴', '🐶', '🐱', '🦋', '🍕', '☕', '🍓', '🍦',
  '⚽', '🎵', '📷', '✈️', '🚗', '💬', '💤', '❗', '❓', '✅', '❌', '➡️',
];

Future<String?> showStickerSheet(BuildContext context) {
  return showModalBottomSheet<String>(
    context: context,
    backgroundColor: AppColors.panel,
    builder: (ctx) => SafeArea(
      child: SizedBox(
        height: 320,
        child: GridView.count(
          crossAxisCount: 6,
          padding: const EdgeInsets.all(12),
          children: [
            for (final e in kStickers)
              InkWell(
                onTap: () => Navigator.pop(ctx, e),
                child: Center(
                  child: Text(e, style: const TextStyle(fontSize: 30)),
                ),
              ),
          ],
        ),
      ),
    ),
  );
}

enum _Param { size, opacity, rotation }

class LayerPanel extends StatefulWidget {
  const LayerPanel({super.key, required this.session});

  final LayerSession session;

  @override
  State<LayerPanel> createState() => _LayerPanelState();
}

class _LayerPanelState extends State<LayerPanel> {
  _Param _param = _Param.size;

  LayerSession get s => widget.session;

  Future<void> _addImage() async {
    try {
      final bytes = await ImagePickerService.pickFromGallery();
      if (bytes == null) return;
      s.addImage(await decodeImage(bytes));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Không mở được ảnh: $e')));
    }
  }

  Future<void> _addSticker() async {
    final e = await showStickerSheet(context);
    if (e != null) s.addSticker(e);
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (context, _) {
        final it = s.selected;
        final int i = s.selectedIndex, n = s.items.length;
        Widget gap() => const SizedBox(width: 8);
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              height: 48,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                children: [
                  ActionChip(
                    avatar: const Icon(Icons.add_photo_alternate, size: 18),
                    label: const Text('Thêm ảnh'),
                    onPressed: () => _addImage(),
                  ),
                  gap(),
                  ActionChip(
                    avatar: const Icon(Icons.emoji_emotions, size: 18),
                    label: const Text('Sticker'),
                    onPressed: () => _addSticker(),
                  ),
                  gap(),
                  ActionChip(
                    label: const Text('Lên trên'),
                    onPressed: it != null && i < n - 1 ? () => s.move(1) : null,
                  ),
                  gap(),
                  ActionChip(
                    label: const Text('Xuống dưới'),
                    onPressed: it != null && i > 0 ? () => s.move(-1) : null,
                  ),
                  gap(),
                  ActionChip(
                    label: const Text('Lật'),
                    onPressed: it == null
                        ? null
                        : () => s.update((x) => x.flipped = !x.flipped),
                  ),
                  gap(),
                  ActionChip(
                    avatar: const Icon(Icons.delete_outline, size: 18),
                    label: const Text('Xóa'),
                    onPressed: it == null ? null : () => s.removeSelected(),
                  ),
                ],
              ),
            ),
            if (n > 0)
              SizedBox(
                height: 44,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  itemCount: n,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (context, k) => ChoiceChip(
                    showCheckmark: false,
                    label: Text('${k + 1}. ${s.items[k].label}'),
                    selected: k == i,
                    onSelected: (_) => s.select(k),
                  ),
                ),
              ),
            if (it == null)
              const Padding(
                padding: EdgeInsets.all(14),
                child: Text(
                  'Thêm ảnh hoặc sticker, kéo để di chuyển.\n'
                  'Dùng 2 ngón để phóng to, thu nhỏ và xoay.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12, color: Colors.white70),
                ),
              )
            else
              Padding(
                padding: const EdgeInsets.only(left: 12, right: 8),
                child: Row(
                  children: [
                    DropdownButton<_Param>(
                      value: _param,
                      underline: const SizedBox(),
                      style: const TextStyle(fontSize: 13, color: Colors.white),
                      items: const [
                        DropdownMenuItem(
                            value: _Param.size, child: Text('Kích thước')),
                        DropdownMenuItem(
                            value: _Param.opacity, child: Text('Độ mờ')),
                        DropdownMenuItem(
                            value: _Param.rotation, child: Text('Xoay')),
                      ],
                      onChanged: (v) => setState(() => _param = v ?? _param),
                    ),
                    Expanded(child: _slider(it)),
                  ],
                ),
              ),
          ],
        );
      },
    );
  }

  Widget _slider(LayerItem it) {
    switch (_param) {
      case _Param.size:
        return Slider(
          min: s.minWidth,
          max: s.maxWidth,
          value: it.width.clamp(s.minWidth, s.maxWidth).toDouble(),
          onChanged: (v) => s.update((x) => x.width = v),
        );
      case _Param.opacity:
        return Slider(
          min: 0.05,
          max: 1,
          value: it.opacity.clamp(0.05, 1.0).toDouble(),
          onChanged: (v) => s.update((x) => x.opacity = v),
        );
      case _Param.rotation:
        double deg = it.rotation * 180 / math.pi;
        deg = (deg + 180) % 360 - 180;
        return Slider(
          min: -180,
          max: 180,
          value: deg.clamp(-180.0, 180.0).toDouble(),
          onChanged: (v) => s.update((x) => x.rotation = v * math.pi / 180),
        );
    }
  }
}
