import 'package:flutter/material.dart';

import 'reshape_model.dart';

class ReshapePanel extends StatelessWidget {
  const ReshapePanel({super.key, required this.session});

  final ReshapeSession session;

  @override
  Widget build(BuildContext context) {
    Widget row(String label, double value, ValueChanged<double> onChanged) {
      return Padding(
        padding: const EdgeInsets.only(left: 16, right: 8),
        child: Row(
          children: [
            SizedBox(
              width: 64,
              child: Text(label, style: const TextStyle(fontSize: 12)),
            ),
            Expanded(
              child: Slider(min: 0, max: 1, value: value, onChanged: onChanged),
            ),
            SizedBox(width: 32, child: Text('${(value * 100).round()}')),
          ],
        ),
      );
    }

    return ListenableBuilder(
      listenable: session,
      builder: (context, _) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 6),
          row('Thon mặt', session.slim, session.setSlim),
          row('Mắt to', session.eyes, session.setEyes),
          const SizedBox(height: 6),
        ],
      ),
    );
  }
}
