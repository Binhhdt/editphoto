import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../../core/image_utils.dart';
import '../ai/face_service.dart';

/// Chinh khuon mat: thon mat va mat to, bang cach keo gian luoi anh.
class ReshapeSession extends ChangeNotifier {
  List<FaceShape> faces = const [];

  /// Thon mat 0..1.
  double slim = 0.35;

  /// Mat to 0..1.
  double eyes = 0.3;

  void begin(List<FaceShape> found) {
    faces = found;
    slim = 0.35;
    eyes = 0.3;
    notifyListeners();
  }

  void setSlim(double v) {
    slim = v;
    notifyListeners();
  }

  void setEyes(double v) {
    eyes = v;
    notifyListeners();
  }

  Size outSize(ui.Image src) =>
      Size(src.width.toDouble(), src.height.toDouble());

  void paint(Canvas canvas, ui.Image src) {
    final double w = src.width.toDouble(), h = src.height.toDouble();
    const int cols = 90;
    final int rows = math.min(220, math.max(2, (cols * h / w).round()));
    final int n = (cols + 1) * (rows + 1);
    final pos = Float32List(n * 2);
    final tex = Float32List(n * 2);

    int v = 0;
    for (int j = 0; j <= rows; j++) {
      for (int i = 0; i <= cols; i++) {
        final double x = w * i / cols, y = h * j / rows;
        double dx = 0, dy = 0;
        final bool edge = i == 0 || j == 0 || i == cols || j == rows;
        if (!edge) {
          for (final f in faces) {
            // Thon mat: keo vung ham ve truc doc cua mat.
            final double cx = f.box.center.dx;
            final double jy = f.box.top + f.box.height * 0.7;
            final double r = f.box.width * 0.8;
            final double d =
                math.sqrt((x - cx) * (x - cx) + (y - jy) * (y - jy)) / r;
            if (d < 1) {
              final double k = (1 - d * d) * (1 - d * d);
              dx += (cx - x) * slim * 0.22 * k;
            }
            // Mat to: day cac diem quanh mat ra xa tam mat.
            for (final e in f.eyes) {
              final double ex = x - e.center.dx, ey = y - e.center.dy;
              final double de = math.sqrt(ex * ex + ey * ey) / e.radius;
              if (de < 1) {
                final double k = (1 - de * de) * (1 - de * de);
                dx += ex * eyes * 0.35 * k;
                dy += ey * eyes * 0.35 * k;
              }
            }
          }
        }
        pos[v] = x + dx;
        pos[v + 1] = y + dy;
        tex[v] = x;
        tex[v + 1] = y;
        v += 2;
      }
    }

    final idx = Uint16List(cols * rows * 6);
    int t = 0;
    for (int j = 0; j < rows; j++) {
      for (int i = 0; i < cols; i++) {
        final int a = j * (cols + 1) + i;
        final int b = a + 1;
        final int c = a + cols + 1;
        final int d = c + 1;
        idx[t++] = a;
        idx[t++] = b;
        idx[t++] = c;
        idx[t++] = b;
        idx[t++] = d;
        idx[t++] = c;
      }
    }

    final vertices = ui.Vertices.raw(
      ui.VertexMode.triangles,
      pos,
      textureCoordinates: tex,
      indices: idx,
    );
    final shader = ui.ImageShader(
      src,
      TileMode.clamp,
      TileMode.clamp,
      Matrix4.identity().storage,
      filterQuality: FilterQuality.medium,
    );
    canvas.drawVertices(vertices, BlendMode.srcOver, Paint()..shader = shader);
  }

  Future<ui.Image> bake(ui.Image src) {
    return renderImage(src.width, src.height, (c) => paint(c, src));
  }
}
