import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';

import '../../core/app_config.dart';
import '../../core/image_utils.dart';
import '../adjust/adjust_model.dart';
import '../ai/face_service.dart';
import '../ai/segmentation_service.dart';
import '../background/background_model.dart';
import '../beauty/beauty_model.dart';
import '../crop/crop_ops.dart';
import '../draw/draw_model.dart';
import '../effects/effect_model.dart';
import '../frames/frame_model.dart';
import '../layers/layer_model.dart';
import '../reshape/reshape_model.dart';
import '../template/template_model.dart';
import '../erase/inpaint_ops.dart';
import '../filters/filter_presets.dart';
import '../history/history_manager.dart';
import '../sharpen/sharpen_ops.dart';
import '../text/text_model.dart';
import '../transform/transform_ops.dart';

enum EditorTool {
  none,
  crop,
  transform,
  adjust,
  filter,
  draw,
  text,
  background,
  sharpen,
  beauty,
  erase,
  layers,
  frame,
  effects,
  template,
  reshape,
}

/// Trung tam dieu khien trinh sua: giu anh goc, lich su va trang thai cong cu.
class EditorController extends ChangeNotifier {
  final HistoryManager _history =
      HistoryManager(maxSteps: AppConfig.maxHistorySteps);

  /// Ban goc, khong bao gio bi sua. Dung cho Reset.
  ui.Image? _original;

  EditorTool tool = EditorTool.none;
  bool _busy = false;
  String? lastError;

  // --- Trang thai tung cong cu ---
  double? cropRatio;
  ui.Rect? cropRect;
  AdjustValues adjust = const AdjustValues();
  AdjustType adjustType = AdjustType.brightness;
  int filterIndex = 0;
  final DrawSession draw = DrawSession();
  final TextSession text = TextSession();
  final BackgroundSession background = BackgroundSession();
  final SharpenSession sharpen = SharpenSession();
  final BeautySession beauty = BeautySession();
  final LayerSession layers = LayerSession();
  final FrameSession frame = FrameSession();
  final EffectSession effects = EffectSession();
  final TemplateSession template = TemplateSession();
  final ReshapeSession reshape = ReshapeSession();

  /// Vung to de xoa vat the (dung lai co che net ve).
  final DrawSession erase = DrawSession()
    ..color = const ui.Color(0x99FF3B30)
    ..size = 28;

  ui.Image? get image => _history.current;
  bool get hasImage => image != null;
  bool get busy => _busy;
  bool get canUndo => !_busy && _history.canUndo;
  bool get canRedo => !_busy && _history.canRedo;
  bool get hasChanges => _history.canUndo;

  void setBusy(bool value) {
    _busy = value;
    notifyListeners();
  }

  // --- Mo anh ---
  Future<void> loadBytes(Uint8List bytes) async {
    if (_busy) return;
    _busy = true;
    notifyListeners();
    try {
      final decoded = await decodeImage(bytes);
      final img = await limitSize(decoded, AppConfig.maxImageSide);
      _original?.dispose();
      _original = img.clone();
      _history.start(img);
      _resetToolState();
      tool = EditorTool.none;
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  // --- Cong cu ---
  void selectTool(EditorTool t) {
    final img = image;
    if (img == null || _busy) return;
    _resetToolState();
    tool = t;
    if (t == EditorTool.draw) draw.begin();
    if (t == EditorTool.erase) {
      erase.begin();
    }
    if (t == EditorTool.text) {
      text.begin(ui.Size(img.width.toDouble(), img.height.toDouble()));
    }
    if (t == EditorTool.sharpen) sharpen.begin(img);
    if (t == EditorTool.layers) {
      layers.begin(ui.Size(img.width.toDouble(), img.height.toDouble()));
    }
    if (t == EditorTool.frame) frame.begin();
    if (t == EditorTool.effects) effects.begin();
    if (t == EditorTool.template) template.begin();
    notifyListeners();
  }

  /// Mo cong cu Nen: AI tach chu the truoc, roi cho chon xoa/mo/thay nen.
  Future<void> openBackground(BgMode mode) async {
    final img = image;
    if (img == null || _busy) return;
    lastError = null;
    _busy = true;
    notifyListeners();
    try {
      final cut = await SegmentationService.cutout(img);
      _resetToolState();
      background.begin(cut, mode);
      tool = EditorTool.background;
    } catch (e) {
      lastError = _aiError(e);
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  /// Mo cong cu Lam dep: AI tim khuon mat truoc.
  Future<void> openBeauty() async {
    final img = image;
    if (img == null || _busy) return;
    lastError = null;
    _busy = true;
    notifyListeners();
    try {
      final faces = await FaceService.detect(img);
      if (faces.isEmpty) {
        lastError = 'Không tìm thấy khuôn mặt trong ảnh';
      } else {
        _resetToolState();
        beauty.begin(faces);
        tool = EditorTool.beauty;
      }
    } catch (e) {
      lastError = _aiError(e);
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  /// Mo cong cu Chinh khuon mat: AI tim khuon mat truoc.
  Future<void> openReshape() async {
    final img = image;
    if (img == null || _busy) return;
    lastError = null;
    _busy = true;
    notifyListeners();
    try {
      final faces = await FaceService.detect(img);
      if (faces.isEmpty) {
        lastError = 'Không tìm thấy khuôn mặt trong ảnh';
      } else {
        _resetToolState();
        reshape.begin(faces);
        tool = EditorTool.reshape;
      }
    } catch (e) {
      lastError = _aiError(e);
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  /// Dong anh dang sua, quay ve man hinh chinh.
  void closeImage() {
    if (_busy) return;
    _resetToolState();
    tool = EditorTool.none;
    _history.clear();
    _original?.dispose();
    _original = null;
    notifyListeners();
  }

  /// Mo mot anh da co san (vi du ket qua Ghep anh) lam anh moi.
  void loadImage(ui.Image img) {
    _original?.dispose();
    _original = img.clone();
    _history.start(img);
    _resetToolState();
    tool = EditorTool.none;
    notifyListeners();
  }

  /// Kich thuoc sau khi tang do phan giai, null neu khong tang duoc nua.
  ui.Size? upscaleTarget() {
    final img = image;
    if (img == null) return null;
    final int longest = math.max(img.width, img.height);
    final double f = math.min(2.0, AppConfig.maxUpscaleSide / longest);
    if (f < 1.1) return null;
    return ui.Size((img.width * f).roundToDouble(),
        (img.height * f).roundToDouble());
  }

  Future<void> upscale() async {
    final img = image;
    final target = upscaleTarget();
    if (img == null || target == null) return;
    lastError = null;
    final double f = target.width / img.width;
    await _commit((s) => upscaleImage(s, f));
  }

  String _aiError(Object e) {
    final s = e.toString();
    final low = s.toLowerCase();
    if (low.contains('download') || low.contains('waiting') ||
        low.contains('module')) {
      return 'Máy đang tải mô hình AI lần đầu (cần mạng). Hãy thử lại sau ít phút.';
    }
    return s.replaceFirst('Exception: ', '');
  }

  void cancelTool() {
    _resetToolState();
    tool = EditorTool.none;
    notifyListeners();
  }

  Future<void> applyTool() async {
    if (_busy) return;
    final img = image;
    if (img == null) return;
    lastError = null;
    switch (tool) {
      case EditorTool.crop:
        final r = cropRect;
        if (r != null &&
            (r.width.round() < img.width || r.height.round() < img.height)) {
          await _commit((s) => cropImage(s, r));
        }
        break;
      case EditorTool.adjust:
        if (!adjust.isNeutral) {
          final m = adjust.toMatrix();
          await _commit((s) => applyColorMatrix(s, m));
        }
        break;
      case EditorTool.filter:
        if (filterIndex != 0) {
          final m = kFilters[filterIndex].matrix;
          await _commit((s) => applyColorMatrix(s, m));
        }
        break;
      case EditorTool.draw:
        if (draw.strokes.isNotEmpty) {
          await _commit((s) => draw.bake(s));
        }
        break;
      case EditorTool.text:
        if (text.items.isNotEmpty) {
          await _commit((s) => text.bake(s));
        }
        break;
      case EditorTool.background:
        if (background.cutout != null) {
          await _commit((s) => background.bake(s));
        }
        break;
      case EditorTool.sharpen:
        if (sharpen.amount > 0.01) {
          final a = sharpen.amount;
          await _commit((s) => sharpenImage(s, a));
        }
        break;
      case EditorTool.beauty:
        if (beauty.faces.isNotEmpty) {
          await _commit((s) => beauty.bake(s));
        }
        break;
      case EditorTool.erase:
        if (erase.strokes.isNotEmpty) {
          await _commit((s) => removeObject(s, erase));
        }
        break;
      case EditorTool.layers:
        if (layers.items.isNotEmpty) {
          // Moi thao tac gan nhat thanh mot buoc lich su rieng,
          // de Undo lui tung thao tac thay vi mat ca layer.
          final base = img;
          for (final st in layers.stepsForBake(4)) {
            await _commit((_) => layers.bakeState(base, st));
          }
        }
        break;
      case EditorTool.frame:
        await _commit((s) => frame.bake(s));
        break;
      case EditorTool.effects:
        if (effects.amount > 0.01) {
          await _commit((s) => effects.bake(s));
        }
        break;
      case EditorTool.template:
        await _commit((s) => template.bake(s));
        break;
      case EditorTool.reshape:
        if (reshape.faces.isNotEmpty) {
          await _commit((s) => reshape.bake(s));
        }
        break;
      case EditorTool.none:
      case EditorTool.transform:
        break;
    }
    cancelTool();
  }

  void _resetToolState() {
    cropRatio = null;
    cropRect = null;
    adjust = const AdjustValues();
    adjustType = AdjustType.brightness;
    filterIndex = 0;
    background.clear();
    sharpen.end();
    layers.clear();
  }

  // --- Crop ---
  void setCropRatio(double? ratio) {
    cropRatio = ratio;
    notifyListeners();
  }

  // --- Adjust ---
  void setAdjustType(AdjustType t) {
    adjustType = t;
    notifyListeners();
  }

  void setAdjustValue(double v) {
    adjust = adjust.set(adjustType, v);
    notifyListeners();
  }

  // --- Filter ---
  void setFilter(int index) {
    filterIndex = index;
    notifyListeners();
  }

  // --- Xoay / lat ---
  Future<void> rotateLeft() => _commit(TransformOps.rotateLeft);
  Future<void> rotateRight() => _commit(TransformOps.rotateRight);
  Future<void> flipHorizontal() => _commit(TransformOps.flipHorizontal);
  Future<void> flipVertical() => _commit(TransformOps.flipVertical);

  // --- Lich su ---
  void undo() {
    if (_busy) return;
    if (_history.undo()) notifyListeners();
  }

  void redo() {
    if (_busy) return;
    if (_history.redo()) notifyListeners();
  }

  /// Dua anh ve ban goc. Van co the Undo de quay lai.
  void reset() {
    final o = _original;
    if (_busy || o == null || !_history.canUndo) return;
    _history.push(o.clone());
    _resetToolState();
    tool = EditorTool.none;
    notifyListeners();
  }

  /// Chay mot phep xu ly anh va dua ket qua vao lich su.
  Future<void> _commit(Future<ui.Image> Function(ui.Image src) op) async {
    final src = image;
    if (src == null || _busy) return;
    _busy = true;
    notifyListeners();
    try {
      final out = await op(src);
      _history.push(out);
    } catch (e) {
      lastError = e.toString().replaceFirst('Exception: ', '');
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _history.clear();
    _original?.dispose();
    draw.dispose();
    erase.dispose();
    text.dispose();
    background.dispose();
    sharpen.dispose();
    beauty.dispose();
    layers.dispose();
    frame.dispose();
    effects.dispose();
    template.dispose();
    reshape.dispose();
    super.dispose();
  }
}
