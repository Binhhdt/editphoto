import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';

import '../../core/app_config.dart';
import '../../core/image_utils.dart';
import '../adjust/adjust_model.dart';
import '../crop/crop_ops.dart';
import '../draw/draw_model.dart';
import '../filters/filter_presets.dart';
import '../history/history_manager.dart';
import '../text/text_model.dart';
import '../transform/transform_ops.dart';

enum EditorTool { none, crop, transform, adjust, filter, draw, text }

/// Trung tam dieu khien trinh sua: giu anh goc, lich su va trang thai cong cu.
class EditorController extends ChangeNotifier {
  final HistoryManager _history =
      HistoryManager(maxSteps: AppConfig.maxHistorySteps);

  /// Ban goc, khong bao gio bi sua. Dung cho Reset.
  ui.Image? _original;

  EditorTool tool = EditorTool.none;
  bool _busy = false;
  String? lastError;

  // --- Trang thai tung cong cu ---
  double? cropRatio;
  ui.Rect? cropRect;
  AdjustValues adjust = const AdjustValues();
  AdjustType adjustType = AdjustType.brightness;
  int filterIndex = 0;
  final DrawSession draw = DrawSession();
  final TextSession text = TextSession();

  ui.Image? get image => _history.current;
  bool get hasImage => image != null;
  bool get busy => _busy;
  bool get canUndo => !_busy && _history.canUndo;
  bool get canRedo => !_busy && _history.canRedo;
  bool get hasChanges => _history.canUndo;

  void setBusy(bool value) {
    _busy = value;
    notifyListeners();
  }

  // --- Mo anh ---
  Future<void> loadBytes(Uint8List bytes) async {
    if (_busy) return;
    _busy = true;
    notifyListeners();
    try {
      final decoded = await decodeImage(bytes);
      final img = await limitSize(decoded, AppConfig.maxImageSide);
      _original?.dispose();
      _original = img.clone();
      _history.start(img);
      _resetToolState();
      tool = EditorTool.none;
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  // --- Cong cu ---
  void selectTool(EditorTool t) {
    final img = image;
    if (img == null || _busy) return;
    _resetToolState();
    tool = t;
    if (t == EditorTool.draw) draw.begin();
    if (t == EditorTool.text) {
      text.begin(ui.Size(img.width.toDouble(), img.height.toDouble()));
    }
    notifyListeners();
  }

  void cancelTool() {
    _resetToolState();
    tool = EditorTool.none;
    notifyListeners();
  }

  Future<void> applyTool() async {
    if (_busy) return;
    final img = image;
    if (img == null) return;
    lastError = null;
    switch (tool) {
      case EditorTool.crop:
        final r = cropRect;
        if (r != null &&
            (r.width.round() < img.width || r.height.round() < img.height)) {
          await _commit((s) => cropImage(s, r));
        }
        break;
      case EditorTool.adjust:
        if (!adjust.isNeutral) {
          final m = adjust.toMatrix();
          await _commit((s) => applyColorMatrix(s, m));
        }
        break;
      case EditorTool.filter:
        if (filterIndex != 0) {
          final m = kFilters[filterIndex].matrix;
          await _commit((s) => applyColorMatrix(s, m));
        }
        break;
      case EditorTool.draw:
        if (draw.strokes.isNotEmpty) {
          await _commit((s) => draw.bake(s));
        }
        break;
      case EditorTool.text:
        if (text.items.isNotEmpty) {
          await _commit((s) => text.bake(s));
        }
        break;
      case EditorTool.none:
      case EditorTool.transform:
        break;
    }
    cancelTool();
  }

  void _resetToolState() {
    cropRatio = null;
    cropRect = null;
    adjust = const AdjustValues();
    adjustType = AdjustType.brightness;
    filterIndex = 0;
  }

  // --- Crop ---
  void setCropRatio(double? ratio) {
    cropRatio = ratio;
    notifyListeners();
  }

  // --- Adjust ---
  void setAdjustType(AdjustType t) {
    adjustType = t;
    notifyListeners();
  }

  void setAdjustValue(double v) {
    adjust = adjust.set(adjustType, v);
    notifyListeners();
  }

  // --- Filter ---
  void setFilter(int index) {
    filterIndex = index;
    notifyListeners();
  }

  // --- Xoay / lat ---
  Future<void> rotateLeft() => _commit(TransformOps.rotateLeft);
  Future<void> rotateRight() => _commit(TransformOps.rotateRight);
  Future<void> flipHorizontal() => _commit(TransformOps.flipHorizontal);
  Future<void> flipVertical() => _commit(TransformOps.flipVertical);

  // --- Lich su ---
  void undo() {
    if (_busy) return;
    if (_history.undo()) notifyListeners();
  }

  void redo() {
    if (_busy) return;
    if (_history.redo()) notifyListeners();
  }

  /// Dua anh ve ban goc. Van co the Undo de quay lai.
  void reset() {
    final o = _original;
    if (_busy || o == null || !_history.canUndo) return;
    _history.push(o.clone());
    _resetToolState();
    tool = EditorTool.none;
    notifyListeners();
  }

  /// Chay mot phep xu ly anh va dua ket qua vao lich su.
  Future<void> _commit(Future<ui.Image> Function(ui.Image src) op) async {
    final src = image;
    if (src == null || _busy) return;
    _busy = true;
    notifyListeners();
    try {
      final out = await op(src);
      _history.push(out);
    } catch (e) {
      lastError = '$e';
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _history.clear();
    _original?.dispose();
    draw.dispose();
    text.dispose();
    super.dispose();
  }
}
