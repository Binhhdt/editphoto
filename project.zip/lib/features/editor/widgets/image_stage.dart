import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

/// Tinh kich thuoc hien thi cua anh (vua khit vung trong, giu ti le)
/// va dua ti le man hinh/pixel anh cho cac cong cu.
class ImageStage extends StatelessWidget {
  const ImageStage({super.key, required this.image, required this.builder});

  final ui.Image image;
  final Widget Function(BuildContext context, double scale, Size size) builder;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        const pad = 12.0;
        final double maxW = math.max(1.0, constraints.maxWidth - pad * 2);
        final double maxH = math.max(1.0, constraints.maxHeight - pad * 2);
        final double scale =
            math.min(maxW / image.width, maxH / image.height);
        final size = Size(image.width * scale, image.height * scale);
        return Center(
          child: SizedBox(
            width: size.width,
            height: size.height,
            child: builder(context, scale, size),
          ),
        );
      },
    );
  }
}
