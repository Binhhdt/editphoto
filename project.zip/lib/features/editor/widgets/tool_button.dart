import 'package:flutter/material.dart';

import '../../../core/app_config.dart';

/// Nut cong cu: icon + ten.
class ToolButton extends StatelessWidget {
  const ToolButton({
    super.key,
    required this.icon,
    required this.label,
    required this.onTap,
    this.selected = false,
    this.quarterTurns = 0,
  });

  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  final bool selected;
  final int quarterTurns;

  @override
  Widget build(BuildContext context) {
    final color = onTap == null
        ? Colors.white30
        : (selected ? AppColors.accent : Colors.white);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: SizedBox(
        width: 76,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            RotatedBox(
              quarterTurns: quarterTurns,
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(height: 5),
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 11, color: color),
            ),
          ],
        ),
      ),
    );
  }
}
