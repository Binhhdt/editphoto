import 'package:flutter/material.dart';

import '../../../core/app_config.dart';

/// Hang chon mau cuon ngang.
class ColorRow extends StatelessWidget {
  const ColorRow({super.key, required this.selected, required this.onSelected});

  final Color? selected;
  final ValueChanged<Color> onSelected;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 44,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        itemCount: kPalette.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (context, i) {
          final c = kPalette[i];
          final isSel = selected == c;
          return GestureDetector(
            onTap: () => onSelected(c),
            child: Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: c,
                shape: BoxShape.circle,
                border: Border.all(
                  color: isSel ? AppColors.accent : Colors.white38,
                  width: isSel ? 3 : 1,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
