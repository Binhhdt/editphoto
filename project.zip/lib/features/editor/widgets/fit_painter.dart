import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Ve noi dung co kich thuoc [outSize] vua khit vao vung hien thi, giu ti le.
class FitPainter extends CustomPainter {
  FitPainter({
    required this.outSize,
    required this.paintContent,
    Listenable? repaint,
  }) : super(repaint: repaint);

  final Size Function() outSize;
  final void Function(Canvas canvas) paintContent;

  @override
  void paint(Canvas canvas, Size size) {
    final o = outSize();
    if (o.width <= 0 || o.height <= 0) return;
    final double k = math.min(size.width / o.width, size.height / o.height);
    canvas.save();
    canvas.translate(
        (size.width - o.width * k) / 2, (size.height - o.height * k) / 2);
    canvas.scale(k);
    canvas.clipRect(Offset.zero & o);
    paintContent(canvas);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant FitPainter oldDelegate) => true;
}
