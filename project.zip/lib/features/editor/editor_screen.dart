import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../../core/app_config.dart';
import '../adjust/adjust_panel.dart';
import '../background/background_model.dart';
import '../background/background_panel.dart';
import '../beauty/beauty_model.dart';
import '../beauty/beauty_panel.dart';
import '../erase/erase_panel.dart';
import '../sharpen/sharpen_panel.dart';
import '../camera/camera_service.dart';
import '../collage/collage_screen.dart';
import '../effects/effect_panel.dart';
import '../frames/frame_panel.dart';
import '../layers/layer_model.dart';
import '../layers/layer_panel.dart';
import '../reshape/reshape_panel.dart';
import '../template/template_panel.dart';
import '../../core/image_utils.dart';
import 'widgets/fit_painter.dart';
import '../crop/crop_panel.dart';
import '../crop/crop_view.dart';
import '../draw/draw_panel.dart';
import '../draw/draw_view.dart';
import '../export/export_service.dart';
import '../export/export_sheet.dart';
import '../filters/filter_panel.dart';
import '../filters/filter_presets.dart';
import '../picker/image_picker_service.dart';
import '../share/share_service.dart';
import '../text/text_panel.dart';
import '../text/text_view.dart';
import '../transform/transform_panel.dart';
import 'editor_controller.dart';
import 'widgets/image_stage.dart';
import 'widgets/tool_button.dart';

class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key});

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  final EditorController c = EditorController();

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  void _toast(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  Future<bool> _confirm(String title, String message) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Hủy'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Đồng ý'),
          ),
        ],
      ),
    );
    return ok ?? false;
  }

  Future<void> _open({required bool camera}) async {
    if (c.busy) return;
    if (c.hasChanges) {
      final ok = await _confirm(
          'Mở ảnh mới?', 'Các chỉnh sửa chưa lưu trên ảnh hiện tại sẽ mất.');
      if (!ok) return;
    }
    try {
      final bytes = camera
          ? await CameraService.capture()
          : await ImagePickerService.pickFromGallery();
      if (bytes == null) return;
      await c.loadBytes(bytes);
    } catch (e) {
      _toast('Không mở được ảnh: $e');
    }
  }

  Future<void> _reset() async {
    if (!c.hasChanges) return;
    final ok =
        await _confirm('Đặt lại ảnh?', 'Ảnh sẽ trở về trạng thái ban đầu.');
    if (ok) c.reset();
  }

  Future<void> _apply() async {
    await c.applyTool();
    final err = c.lastError;
    if (err != null) _toast('Lỗi xử lý ảnh: $err');
  }

  Future<void> _export() async {
    final img = c.image;
    if (img == null || c.busy) return;
    final req =
        await showExportSheet(context, width: img.width, height: img.height);
    if (req == null) return;
    final current = c.image;
    if (current == null) return;

    c.setBusy(true);
    try {
      final File file = await ExportService.renderToFile(current, req.options);
      if (req.share) {
        c.setBusy(false);
        await ShareService.shareFile(file);
      } else {
        await ExportService.saveToGallery(file);
        c.setBusy(false);
        if (!mounted) return;
        ScaffoldMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(SnackBar(
            content: const Text('Đã lưu ảnh thành công'),
            action: SnackBarAction(
              label: 'Chia sẻ',
              onPressed: () => ShareService.shareFile(file),
            ),
          ));
      }
    } catch (e) {
      _toast('Không lưu được ảnh: $e');
    } finally {
      if (c.busy) c.setBusy(false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: c,
      builder: (context, _) {
        final img = c.image;
        return PopScope(
          canPop: c.tool == EditorTool.none,
          onPopInvoked: (didPop) {
            if (!didPop) c.cancelTool();
          },
          child: Scaffold(
            body: SafeArea(
              child: Stack(
                children: [
                  Column(
                    children: [
                      _topBar(),
                      Expanded(
                        child: img == null ? _emptyState() : _stage(img),
                      ),
                      if (img != null)
                        Container(
                          width: double.infinity,
                          color: AppColors.panel,
                          child: _bottom(),
                        ),
                    ],
                  ),
                  if (c.busy)
                    Positioned.fill(
                      child: AbsorbPointer(
                        child: Container(
                          color: Colors.black45,
                          alignment: Alignment.center,
                          child: const CircularProgressIndicator(),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void _showError() {
    final err = c.lastError;
    if (err != null) _toast(err);
  }

  Future<void> _openBg(BgMode mode) async {
    await c.openBackground(mode);
    _showError();
  }

  Future<void> _openReshape() async {
    await c.openReshape();
    _showError();
  }

  Future<void> _sticker() async {
    c.selectTool(EditorTool.layers);
    if (c.tool != EditorTool.layers) return;
    final e = await showStickerSheet(context);
    if (e != null && c.tool == EditorTool.layers) c.layers.addSticker(e);
  }

  /// Chon 2-6 anh, ghep thanh mot anh roi mo trong trinh sua.
  Future<void> _collage() async {
    if (c.busy) return;
    if (c.hasChanges) {
      final ok = await _confirm('Ghép ảnh mới?',
          'Các chỉnh sửa chưa lưu trên ảnh hiện tại sẽ mất.');
      if (!ok) return;
    }
    final images = <ui.Image>[];
    try {
      final list = await ImagePickerService.pickMultiple();
      if (list.isEmpty) return;
      if (list.length < 2) {
        _toast('Hãy chọn ít nhất 2 ảnh để ghép');
        return;
      }
      for (final bytes in list.take(6)) {
        images.add(await decodeImage(bytes));
      }
    } catch (e) {
      for (final img in images) {
        img.dispose();
      }
      _toast('Không mở được ảnh: $e');
      return;
    }
    if (!mounted) return;
    final result = await Navigator.push<ui.Image>(
      context,
      MaterialPageRoute(builder: (_) => CollageScreen(images: images)),
    );
    if (result != null) c.loadImage(result);
  }

  Future<void> _openBeauty() async {
    await c.openBeauty();
    _showError();
  }

  Future<void> _upscale() async {
    final img = c.image;
    if (img == null || c.busy) return;
    final target = c.upscaleTarget();
    if (target == null) {
      _toast('Ảnh đã ở kích thước tối đa, không tăng thêm được');
      return;
    }
    final ok = await _confirm(
      'Tăng độ phân giải?',
      'Ảnh sẽ tăng từ ${img.width} × ${img.height} lên '
          '${target.width.round()} × ${target.height.round()} và được làm nét nhẹ.',
    );
    if (!ok) return;
    await c.upscale();
    _showError();
  }

  // ---------------- Thanh tren ----------------

  Widget _topBar() {
    if (c.tool != EditorTool.none) return _toolTopBar();
    final has = c.hasImage;
    return SizedBox(
      height: 52,
      child: Row(
        children: [
          _iconBtn(Icons.photo_library_outlined, 'Chọn ảnh',
              () => _open(camera: false)),
          _iconBtn(Icons.photo_camera_outlined, 'Chụp ảnh',
              () => _open(camera: true)),
          const Spacer(),
          _iconBtn(Icons.undo, 'Undo', c.canUndo ? () => c.undo() : null),
          _iconBtn(Icons.redo, 'Redo', c.canRedo ? () => c.redo() : null),
          _iconBtn(Icons.restart_alt, 'Reset',
              has && c.hasChanges ? () => _reset() : null),
          Padding(
            padding: const EdgeInsets.only(left: 2, right: 8),
            child: FilledButton(
              style: FilledButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                minimumSize: const Size(0, 36),
              ),
              onPressed: has ? () => _export() : null,
              child: const Text('Lưu'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _toolTopBar() {
    final isTransform = c.tool == EditorTool.transform;
    return SizedBox(
      height: 52,
      child: Row(
        children: [
          if (isTransform)
            const SizedBox(width: 48)
          else
            _iconBtn(Icons.close, 'Hủy', () => c.cancelTool()),
          Expanded(
            child: Text(
              _toolTitle(c.tool),
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
          ),
          IconButton(
            tooltip: isTransform ? 'Xong' : 'Áp dụng',
            icon: const Icon(Icons.check, color: AppColors.accent),
            onPressed: () => _apply(),
          ),
        ],
      ),
    );
  }

  String _toolTitle(EditorTool t) {
    switch (t) {
      case EditorTool.crop:
        return 'Cắt ảnh';
      case EditorTool.transform:
        return 'Xoay & Lật';
      case EditorTool.adjust:
        return 'Điều chỉnh';
      case EditorTool.filter:
        return 'Filter';
      case EditorTool.draw:
        return 'Vẽ';
      case EditorTool.text:
        return 'Chữ';
      case EditorTool.background:
        return 'Nền';
      case EditorTool.sharpen:
        return 'Làm nét';
      case EditorTool.beauty:
        return 'Làm đẹp khuôn mặt';
      case EditorTool.erase:
        return 'Xóa vật thể';
      case EditorTool.layers:
        return 'Layer & Sticker';
      case EditorTool.frame:
        return 'Khung ảnh';
      case EditorTool.effects:
        return 'Hiệu ứng';
      case EditorTool.template:
        return 'Template';
      case EditorTool.reshape:
        return 'Chỉnh khuôn mặt';
      case EditorTool.none:
        return '';
    }
  }

  Widget _iconBtn(IconData icon, String tip, VoidCallback? onTap) {
    return IconButton(
      tooltip: tip,
      visualDensity: VisualDensity.compact,
      icon: Icon(icon),
      onPressed: onTap,
    );
  }

  // ---------------- Man hinh cho ----------------

  Widget _emptyState() {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.image_outlined, size: 72, color: AppColors.muted),
            const SizedBox(height: 12),
            const Text('Chưa có ảnh',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            const Text('Chọn một ảnh để bắt đầu chỉnh sửa',
                style: TextStyle(color: AppColors.muted)),
            const SizedBox(height: 24),
            FilledButton.icon(
              icon: const Icon(Icons.photo_library_outlined),
              label: const Text('Chọn ảnh'),
              style: FilledButton.styleFrom(minimumSize: const Size(200, 48)),
              onPressed: () => _open(camera: false),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              icon: const Icon(Icons.photo_camera_outlined),
              label: const Text('Chụp ảnh'),
              style: OutlinedButton.styleFrom(minimumSize: const Size(200, 48)),
              onPressed: () => _open(camera: true),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              icon: const Icon(Icons.grid_view),
              label: const Text('Ghép ảnh'),
              style: OutlinedButton.styleFrom(minimumSize: const Size(200, 48)),
              onPressed: () => _collage(),
            ),
          ],
        ),
      ),
    );
  }

  // ---------------- Vung anh ----------------

  /// Cac cong cu co ket qua khac kich thuoc anh goc thi tu canh vua man hinh.
  Widget? _fitStage(ui.Image img) {
    FitPainter? p;
    switch (c.tool) {
      case EditorTool.frame:
        p = FitPainter(
          outSize: () => c.frame.outSize(img),
          paintContent: (cv) => c.frame.paint(cv, img),
          repaint: c.frame,
        );
        break;
      case EditorTool.effects:
        p = FitPainter(
          outSize: () => c.effects.outSize(img),
          paintContent: (cv) => c.effects.paint(cv, img),
          repaint: c.effects,
        );
        break;
      case EditorTool.template:
        p = FitPainter(
          outSize: () => c.template.outSize(img),
          paintContent: (cv) => c.template.paint(cv, img),
          repaint: c.template,
        );
        break;
      case EditorTool.reshape:
        p = FitPainter(
          outSize: () => c.reshape.outSize(img),
          paintContent: (cv) => c.reshape.paint(cv, img),
          repaint: c.reshape,
        );
        break;
      default:
        return null;
    }
    return Padding(
      padding: const EdgeInsets.all(12),
      child: CustomPaint(size: Size.infinite, painter: p),
    );
  }

  Widget _stage(ui.Image img) {
    final fitted = _fitStage(img);
    if (fitted != null) return fitted;
    final stage = ImageStage(
      image: img,
      builder: (context, scale, size) {
        final Widget raw = RawImage(
          image: img,
          width: size.width,
          height: size.height,
          fit: BoxFit.fill,
          filterQuality: FilterQuality.medium,
        );
        switch (c.tool) {
          case EditorTool.crop:
            return CropView(
              size: size,
              scale: scale,
              ratio: c.cropRatio,
              onChanged: (r) => c.cropRect = r,
              child: raw,
            );
          case EditorTool.adjust:
            return ColorFiltered(
              colorFilter: ColorFilter.matrix(c.adjust.toMatrix()),
              child: raw,
            );
          case EditorTool.filter:
            return ColorFiltered(
              colorFilter: ColorFilter.matrix(kFilters[c.filterIndex].matrix),
              child: raw,
            );
          case EditorTool.draw:
            return Stack(
              children: [
                raw,
                Positioned.fill(
                  child: DrawView(session: c.draw, scale: scale),
                ),
              ],
            );
          case EditorTool.text:
            return Stack(
              children: [
                raw,
                Positioned.fill(
                  child: TextView(session: c.text, scale: scale),
                ),
              ],
            );
          case EditorTool.background:
            return CustomPaint(
              size: size,
              painter: BackgroundPainter(c.background, img, scale),
            );
          case EditorTool.sharpen:
            return ListenableBuilder(
              listenable: c.sharpen,
              builder: (context, _) => RawImage(
                image: c.sharpen.preview ?? img,
                width: size.width,
                height: size.height,
                fit: BoxFit.fill,
                filterQuality: FilterQuality.medium,
              ),
            );
          case EditorTool.beauty:
            return CustomPaint(
              size: size,
              painter: BeautyPainter(c.beauty, img, scale),
            );
          case EditorTool.erase:
            return Stack(
              children: [
                raw,
                Positioned.fill(
                  child: DrawView(session: c.erase, scale: scale),
                ),
              ],
            );
          case EditorTool.layers:
            return Stack(
              children: [
                raw,
                Positioned.fill(
                  child: LayerView(session: c.layers, scale: scale),
                ),
              ],
            );
          case EditorTool.frame:
          case EditorTool.effects:
          case EditorTool.template:
          case EditorTool.reshape:
          case EditorTool.none:
          case EditorTool.transform:
            return raw;
        }
      },
    );
    if (c.tool == EditorTool.none) {
      // Cho phep zoom bang 2 ngon khi dang xem.
      return InteractiveViewer(maxScale: 6, child: stage);
    }
    return stage;
  }

  // ---------------- Thanh duoi ----------------

  Widget _bottom() {
    switch (c.tool) {
      case EditorTool.none:
        return _mainToolbar();
      case EditorTool.crop:
        return CropPanel(controller: c);
      case EditorTool.transform:
        return TransformPanel(controller: c);
      case EditorTool.adjust:
        return AdjustPanel(controller: c);
      case EditorTool.filter:
        return FilterPanel(controller: c);
      case EditorTool.draw:
        return DrawPanel(session: c.draw);
      case EditorTool.text:
        return TextPanel(session: c.text);
      case EditorTool.background:
        return BackgroundPanel(session: c.background);
      case EditorTool.sharpen:
        return SharpenPanel(session: c.sharpen);
      case EditorTool.beauty:
        return BeautyPanel(session: c.beauty);
      case EditorTool.erase:
        return ErasePanel(session: c.erase);
      case EditorTool.layers:
        return LayerPanel(session: c.layers);
      case EditorTool.frame:
        return FramePanel(session: c.frame);
      case EditorTool.effects:
        return EffectPanel(session: c.effects);
      case EditorTool.template:
        return TemplatePanel(session: c.template);
      case EditorTool.reshape:
        return ReshapePanel(session: c.reshape);
    }
  }

  Widget _mainToolbar() {
    Widget btn(IconData icon, String label, EditorTool tool) => ToolButton(
          icon: icon,
          label: label,
          onTap: () => c.selectTool(tool),
        );
    Widget act(IconData icon, String label, VoidCallback onTap) =>
        ToolButton(icon: icon, label: label, onTap: onTap);
    return SizedBox(
      height: 76,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 6),
        children: [
          btn(Icons.crop, 'Cắt', EditorTool.crop),
          btn(Icons.rotate_90_degrees_ccw, 'Xoay & Lật', EditorTool.transform),
          btn(Icons.tune, 'Điều chỉnh', EditorTool.adjust),
          btn(Icons.auto_awesome, 'Filter', EditorTool.filter),
          btn(Icons.brush, 'Vẽ', EditorTool.draw),
          btn(Icons.text_fields, 'Chữ', EditorTool.text),
          act(Icons.auto_fix_high, 'Xóa nền', () => _openBg(BgMode.remove)),
          act(Icons.blur_on, 'Mờ nền', () => _openBg(BgMode.blur)),
          act(Icons.wallpaper, 'Thay nền', () => _openBg(BgMode.color)),
          btn(Icons.healing, 'Xóa vật thể', EditorTool.erase),
          btn(Icons.center_focus_strong, 'Làm nét', EditorTool.sharpen),
          act(Icons.hd_outlined, 'Tăng nét 2x', () => _upscale()),
          act(Icons.face_retouching_natural, 'Làm đẹp', () => _openBeauty()),
          act(Icons.face, 'Chỉnh mặt', () => _openReshape()),
          btn(Icons.layers, 'Layer', EditorTool.layers),
          act(Icons.emoji_emotions_outlined, 'Sticker', () => _sticker()),
          btn(Icons.filter_frames, 'Khung ảnh', EditorTool.frame),
          btn(Icons.auto_awesome_motion, 'Hiệu ứng', EditorTool.effects),
          btn(Icons.dashboard_customize, 'Template', EditorTool.template),
          act(Icons.grid_view, 'Ghép ảnh', () => _collage()),
        ],
      ),
    );
  }
}
