import 'dart:io';

import 'package:path_provider/path_provider.dart';

/// Luu ban sao cac anh da luu gan day de hien o man hinh chinh.
class RecentStore {
  static const int maxItems = 12;

  static Future<Directory> _dir() async {
    final base = await getApplicationDocumentsDirectory();
    final d = Directory('${base.path}/recent');
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  /// Danh sach anh gan day, moi nhat truoc.
  static Future<List<File>> list() async {
    try {
      final d = await _dir();
      final files = d.listSync().whereType<File>().toList();
      files.sort(
          (a, b) => b.lastModifiedSync().compareTo(a.lastModifiedSync()));
      return files;
    } catch (_) {
      return [];
    }
  }

  static Future<void> add(File src) async {
    try {
      final d = await _dir();
      final name = src.uri.pathSegments.last;
      await src.copy('${d.path}/$name');
      final all = await list();
      for (final f in all.skip(maxItems)) {
        try {
          f.deleteSync();
        } catch (_) {}
      }
    } catch (_) {}
  }

  static Future<void> remove(File f) async {
    try {
      await f.delete();
    } catch (_) {}
  }
}
