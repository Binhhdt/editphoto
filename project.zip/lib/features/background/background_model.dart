import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../../core/image_utils.dart';

enum BgMode { remove, blur, color, image }

/// Trang thai cong cu Nen: xoa nen, lam mo nen, thay nen.
class BackgroundSession extends ChangeNotifier {
  /// Chu the da tach, nen trong suot.
  ui.Image? cutout;
  BgMode mode = BgMode.remove;

  /// Do mo nen 0..1.
  double blur = 0.5;
  Color color = Colors.white;
  ui.Image? bgImage;

  void begin(ui.Image cut, BgMode m) {
    clear();
    cutout = cut;
    mode = m;
    notifyListeners();
  }

  void setMode(BgMode m) {
    mode = m;
    notifyListeners();
  }

  void setBlur(double v) {
    blur = v;
    notifyListeners();
  }

  void setColor(Color c) {
    color = c;
    mode = BgMode.color;
    notifyListeners();
  }

  void setBgImage(ui.Image img) {
    bgImage?.dispose();
    bgImage = img;
    mode = BgMode.image;
    notifyListeners();
  }

  void clear() {
    cutout?.dispose();
    cutout = null;
    bgImage?.dispose();
    bgImage = null;
    blur = 0.5;
    color = Colors.white;
  }

  /// Ve ket qua len canvas theo toa do pixel anh.
  void paint(Canvas canvas, ui.Image src, {bool preview = false}) {
    final cut = cutout;
    if (cut == null) {
      canvas.drawImage(src, Offset.zero, Paint());
      return;
    }
    final double w = src.width.toDouble();
    final double h = src.height.toDouble();
    final bounds = Rect.fromLTWH(0, 0, w, h);
    canvas.save();
    canvas.clipRect(bounds);
    switch (mode) {
      case BgMode.remove:
        if (preview) _checker(canvas, bounds);
        break;
      case BgMode.blur:
        final double sigma = 2 + blur * bounds.shortestSide * 0.04;
        canvas.drawImage(
          src,
          Offset.zero,
          Paint()
            ..imageFilter = ui.ImageFilter.blur(
              sigmaX: sigma,
              sigmaY: sigma,
              tileMode: TileMode.clamp,
            ),
        );
        break;
      case BgMode.color:
        canvas.drawRect(bounds, Paint()..color = color);
        break;
      case BgMode.image:
        final bg = bgImage;
        if (bg == null) {
          canvas.drawRect(bounds, Paint()..color = color);
        } else {
          // Phu kin (cover), giu ti le.
          final double s = (w / bg.width > h / bg.height)
              ? w / bg.width
              : h / bg.height;
          final double sw = w / s, sh = h / s;
          final srcRect = Rect.fromLTWH(
              (bg.width - sw) / 2, (bg.height - sh) / 2, sw, sh);
          canvas.drawImageRect(bg, srcRect, bounds,
              Paint()..filterQuality = FilterQuality.medium);
        }
        break;
    }
    canvas.drawImage(cut, Offset.zero, Paint());
    canvas.restore();
  }

  void _checker(Canvas canvas, Rect bounds) {
    canvas.drawRect(bounds, Paint()..color = const Color(0xFFCCCCCC));
    final double cell = bounds.shortestSide / 20;
    final dark = Paint()..color = const Color(0xFF999999);
    int row = 0;
    for (double y = 0; y < bounds.height; y += cell, row++) {
      int col = 0;
      for (double x = 0; x < bounds.width; x += cell, col++) {
        if ((row + col) % 2 == 0) {
          canvas.drawRect(Rect.fromLTWH(x, y, cell, cell), dark);
        }
      }
    }
  }

  Future<ui.Image> bake(ui.Image src) {
    return renderImage(src.width, src.height, (c) => paint(c, src));
  }

  @override
  void dispose() {
    clear();
    super.dispose();
  }
}

/// Xem truoc ket qua tren man hinh.
class BackgroundPainter extends CustomPainter {
  BackgroundPainter(this.session, this.src, this.scale)
      : super(repaint: session);

  final BackgroundSession session;
  final ui.Image src;
  final double scale;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(scale);
    session.paint(canvas, src, preview: true);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant BackgroundPainter oldDelegate) =>
      oldDelegate.src != src || oldDelegate.scale != scale;
}
