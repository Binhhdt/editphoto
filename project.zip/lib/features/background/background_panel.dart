import 'package:flutter/material.dart';

import '../../core/image_utils.dart';
import '../editor/widgets/color_row.dart';
import '../picker/image_picker_service.dart';
import 'background_model.dart';

class BackgroundPanel extends StatelessWidget {
  const BackgroundPanel({super.key, required this.session});

  final BackgroundSession session;

  Future<void> _pickImage(BuildContext context) async {
    try {
      final bytes = await ImagePickerService.pickFromGallery();
      if (bytes == null) return;
      session.setBgImage(await decodeImage(bytes));
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Không mở được ảnh nền: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: session,
      builder: (context, _) {
        Widget chip(String label, BgMode m) => Padding(
              padding: const EdgeInsets.only(right: 8),
              child: ChoiceChip(
                showCheckmark: false,
                label: Text(label),
                selected: session.mode == m,
                onSelected: (_) => session.setMode(m),
              ),
            );
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              height: 52,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                children: [
                  chip('Xóa nền', BgMode.remove),
                  chip('Làm mờ nền', BgMode.blur),
                  chip('Nền màu', BgMode.color),
                  chip('Nền ảnh', BgMode.image),
                ],
              ),
            ),
            if (session.mode == BgMode.remove)
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 4, 16, 14),
                child: Text(
                  'Nền sẽ trong suốt. Hãy lưu dạng PNG hoặc WebP để giữ nền trong suốt.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12, color: Colors.white70),
                ),
              ),
            if (session.mode == BgMode.blur)
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 8),
                child: Row(
                  children: [
                    const Text('Độ mờ', style: TextStyle(fontSize: 12)),
                    Expanded(
                      child: Slider(
                        min: 0,
                        max: 1,
                        value: session.blur,
                        onChanged: session.setBlur,
                      ),
                    ),
                  ],
                ),
              ),
            if (session.mode == BgMode.color)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: ColorRow(
                  selected: session.color,
                  onSelected: session.setColor,
                ),
              ),
            if (session.mode == BgMode.image)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                child: FilledButton.icon(
                  icon: const Icon(Icons.photo_library_outlined),
                  label: Text(session.bgImage == null
                      ? 'Chọn ảnh nền'
                      : 'Đổi ảnh nền khác'),
                  onPressed: () => _pickImage(context),
                ),
              ),
          ],
        );
      },
    );
  }
}
