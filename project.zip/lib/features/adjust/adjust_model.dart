import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../core/color_matrix.dart';

enum AdjustType {
  brightness('Độ sáng', Icons.brightness_6),
  contrast('Tương phản', Icons.contrast),
  saturation('Bão hòa', Icons.palette_outlined),
  exposure('Phơi sáng', Icons.exposure),
  temperature('Nhiệt độ', Icons.thermostat);

  const AdjustType(this.label, this.icon);
  final String label;
  final IconData icon;
}

/// Gia tri cac slider, moi gia tri trong khoang -1..1 (0 = khong doi).
class AdjustValues {
  const AdjustValues([this._values = const {}]);

  final Map<AdjustType, double> _values;

  double operator [](AdjustType type) => _values[type] ?? 0;

  AdjustValues set(AdjustType type, double value) =>
      AdjustValues({..._values, type: value});

  bool get isNeutral => _values.values.every((v) => v.abs() < 0.005);

  List<double> toMatrix() {
    final e = this[AdjustType.exposure];
    final t = this[AdjustType.temperature];
    final c = this[AdjustType.contrast];
    final b = this[AdjustType.brightness];
    final s = this[AdjustType.saturation];
    final double ev = math.pow(2.0, e).toDouble();
    return CM.chain([
      CM.scale(ev, ev, ev),
      CM.scale(1 + 0.25 * t, 1 + 0.03 * t, 1 - 0.25 * t),
      CM.contrast(c >= 0 ? 1 + c : 1 + c * 0.8),
      CM.offset(b * 90),
      CM.saturation(1 + s),
    ]);
  }
}
