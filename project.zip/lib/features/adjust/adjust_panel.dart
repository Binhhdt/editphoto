import 'package:flutter/material.dart';

import '../../core/app_config.dart';
import '../editor/editor_controller.dart';
import 'adjust_model.dart';

class AdjustPanel extends StatelessWidget {
  const AdjustPanel({super.key, required this.controller});

  final EditorController controller;

  @override
  Widget build(BuildContext context) {
    final type = controller.adjustType;
    final value = controller.adjust[type];
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 8, 0),
          child: Row(
            children: [
              SizedBox(
                width: 40,
                child: Text(
                  '${(value * 100).round()}',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              Expanded(
                child: Slider(
                  min: -1,
                  max: 1,
                  value: value,
                  onChanged: controller.setAdjustValue,
                ),
              ),
              IconButton(
                tooltip: 'Về 0',
                icon: const Icon(Icons.refresh, size: 20),
                onPressed: () => controller.setAdjustValue(0),
              ),
            ],
          ),
        ),
        SizedBox(
          height: 68,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 8),
            children: [
              for (final t in AdjustType.values)
                _TypeButton(
                  type: t,
                  selected: t == type,
                  changed: controller.adjust[t].abs() >= 0.005,
                  onTap: () => controller.setAdjustType(t),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class _TypeButton extends StatelessWidget {
  const _TypeButton({
    required this.type,
    required this.selected,
    required this.changed,
    required this.onTap,
  });

  final AdjustType type;
  final bool selected;
  final bool changed;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = selected ? AppColors.accent : Colors.white;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: SizedBox(
        width: 84,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(type.icon, color: color, size: 22),
            const SizedBox(height: 4),
            Text(
              type.label,
              style: TextStyle(fontSize: 11, color: color),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 2),
            Container(
              width: 5,
              height: 5,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: changed ? AppColors.accent : Colors.transparent,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
