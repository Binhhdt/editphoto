import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';

import '../../core/temp_image.dart';

/// Vung da mat cua mot khuon mat, toa do pixel anh.
class FaceShape {
  const FaceShape(this.skin, this.box);
  final ui.Path skin;
  final ui.Rect box;
}

/// Nhan dien khuon mat bang ML Kit (chay tren may).
class FaceService {
  static Future<List<FaceShape>> detect(ui.Image src) async {
    final tmp = await writeTempPng(src, 1280);
    final double k = src.width / tmp.width;
    final detector = FaceDetector(
      options: FaceDetectorOptions(
        performanceMode: FaceDetectorMode.accurate,
        enableContours: true,
      ),
    );
    try {
      final faces =
          await detector.processImage(InputImage.fromFilePath(tmp.path));
      final out = <FaceShape>[];
      for (final f in faces) {
        final b = f.boundingBox;
        final box =
            ui.Rect.fromLTRB(b.left * k, b.top * k, b.right * k, b.bottom * k);

        List<ui.Offset>? pts(FaceContourType t) {
          final p = f.contours[t]?.points;
          if (p == null || p.length < 3) return null;
          return [for (final q in p) ui.Offset(q.x * k, q.y * k)];
        }

        ui.Path skin;
        final outline = pts(FaceContourType.face);
        if (outline != null) {
          skin = ui.Path()..addPolygon(outline, true);
        } else {
          skin = ui.Path()..addOval(box);
        }

        // Khong lam min mat va moi.
        final holes = <List<ui.Offset>>[];
        final le = pts(FaceContourType.leftEye);
        final re = pts(FaceContourType.rightEye);
        if (le != null) holes.add(_inflate(le, 1.6));
        if (re != null) holes.add(_inflate(re, 1.6));
        final lipTop = pts(FaceContourType.upperLipTop);
        final lipBottom = pts(FaceContourType.lowerLipBottom);
        if (lipTop != null && lipBottom != null) {
          holes.add(_inflate([...lipTop, ...lipBottom.reversed], 1.15));
        }
        for (final h in holes) {
          skin = ui.Path.combine(
            ui.PathOperation.difference,
            skin,
            ui.Path()..addPolygon(h, true),
          );
        }
        out.add(FaceShape(skin, box));
      }
      return out;
    } finally {
      detector.close();
      deleteTemp(tmp.path);
    }
  }

  static List<ui.Offset> _inflate(List<ui.Offset> pts, double factor) {
    double cx = 0, cy = 0;
    for (final p in pts) {
      cx += p.dx;
      cy += p.dy;
    }
    cx /= math.max(1, pts.length);
    cy /= math.max(1, pts.length);
    return [
      for (final p in pts)
        ui.Offset(cx + (p.dx - cx) * factor, cy + (p.dy - cy) * factor)
    ];
  }
}
