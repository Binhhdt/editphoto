import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:google_mlkit_subject_segmentation/google_mlkit_subject_segmentation.dart';

import '../../core/image_utils.dart';
import '../../core/temp_image.dart';

/// Tach chu the khoi nen bang ML Kit Subject Segmentation (chay tren may).
class SegmentationService {
  /// Tra ve anh chi con chu the, nen trong suot, cung kich thuoc voi [src].
  static Future<ui.Image> cutout(ui.Image src) async {
    final tmp = await writeTempPng(src, 1024);
    final segmenter = SubjectSegmenter(
      options: SubjectSegmenterOptions(
        enableForegroundConfidenceMask: true,
        enableForegroundBitmap: false,
        enableMultipleSubjects: SubjectResultOptions(
          enableConfidenceMask: false,
          enableSubjectBitmap: false,
        ),
      ),
    );
    try {
      final result =
          await segmenter.processImage(InputImage.fromFilePath(tmp.path));
      final List<double>? conf = result.foregroundConfidenceMask;
      final int n = tmp.width * tmp.height;
      if (conf == null || conf.length != n) {
        throw Exception('Không tách được chủ thể trong ảnh này');
      }
      final bytes = Uint8List(n * 4);
      for (int i = 0; i < n; i++) {
        double a = (conf[i] - 0.3) / 0.4;
        if (a < 0) a = 0;
        if (a > 1) a = 1;
        final int v = (a * 255).round();
        final int o = i * 4;
        bytes[o] = v;
        bytes[o + 1] = v;
        bytes[o + 2] = v;
        bytes[o + 3] = v;
      }
      final mask = await imageFromRgba(bytes, tmp.width, tmp.height);
      final bounds =
          ui.Rect.fromLTWH(0, 0, src.width.toDouble(), src.height.toDouble());
      final out = await renderImage(src.width, src.height, (c) {
        c.saveLayer(bounds, ui.Paint());
        c.drawImage(src, ui.Offset.zero, ui.Paint());
        c.drawImageRect(
          mask,
          ui.Rect.fromLTWH(0, 0, tmp.width.toDouble(), tmp.height.toDouble()),
          bounds,
          ui.Paint()
            ..blendMode = ui.BlendMode.dstIn
            ..filterQuality = ui.FilterQuality.medium,
        );
        c.restore();
      });
      mask.dispose();
      return out;
    } finally {
      segmenter.close();
      deleteTemp(tmp.path);
    }
  }
}
