import 'package:flutter/material.dart';

/// Cau hinh chung cua app. Sua o day de doi gioi han.
class AppConfig {
  /// Canh dai toi da cua anh khi mo (px). Giam neu may yeu.
  static const double maxImageSide = 2400;

  /// So buoc Undo toi da duoc giu trong bo nho.
  static const int maxHistorySteps = 10;

  /// Canh dai toi da sau khi tang do phan giai (px).
  static const double maxUpscaleSide = 4000;
}

class AppColors {
  static const Color background = Color(0xFF0F0F12);
  static const Color panel = Color(0xFF1B1B21);
  static const Color accent = Color(0xFF4F8CFF);
  static const Color muted = Color(0xFF9A9AA5);
}

/// Bang mau dung chung cho Ve va Chu.
const List<Color> kPalette = [
  Colors.white,
  Colors.black,
  Color(0xFFFF3B30),
  Color(0xFFFF9500),
  Color(0xFFFFCC00),
  Color(0xFF34C759),
  Color(0xFF00C7BE),
  Color(0xFF007AFF),
  Color(0xFF5856D6),
  Color(0xFFAF52DE),
  Color(0xFFFF2D55),
  Color(0xFFA2845E),
  Color(0xFF8E8E93),
];
