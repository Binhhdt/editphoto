import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:path_provider/path_provider.dart';

import 'image_utils.dart';

class TempImage {
  const TempImage(this.path, this.width, this.height);
  final String path;
  final int width;
  final int height;
}

/// Ghi anh ra file PNG tam (thu nho neu canh dai > maxSide) de dua cho ML Kit.
Future<TempImage> writeTempPng(ui.Image src, int maxSide) async {
  final int longest = math.max(src.width, src.height);
  final double k = longest > maxSide ? maxSide / longest : 1.0;
  final int w = math.max(1, (src.width * k).round());
  final int h = math.max(1, (src.height * k).round());
  final small = await renderImage(w, h, (c) {
    c.drawImageRect(
      src,
      ui.Rect.fromLTWH(0, 0, src.width.toDouble(), src.height.toDouble()),
      ui.Rect.fromLTWH(0, 0, w.toDouble(), h.toDouble()),
      ui.Paint()..filterQuality = ui.FilterQuality.medium,
    );
  });
  final data = await small.toByteData(format: ui.ImageByteFormat.png);
  small.dispose();
  if (data == null) throw Exception('Không mã hóa được ảnh');
  final dir = await getTemporaryDirectory();
  final path = '${dir.path}/ai_${DateTime.now().microsecondsSinceEpoch}.png';
  await File(path).writeAsBytes(data.buffer.asUint8List(), flush: true);
  return TempImage(path, w, h);
}

void deleteTemp(String path) {
  try {
    File(path).deleteSync();
  } catch (_) {}
}

/// Tao ui.Image tu mang pixel RGBA.
Future<ui.Image> imageFromRgba(Uint8List bytes, int width, int height) {
  final completer = Completer<ui.Image>();
  ui.decodeImageFromPixels(
    bytes,
    width,
    height,
    ui.PixelFormat.rgba8888,
    (img) => completer.complete(img),
  );
  return completer.future;
}

/// Lay mang pixel RGBA cua anh.
Future<Uint8List> imageToRgba(ui.Image src) async {
  final data = await src.toByteData(format: ui.ImageByteFormat.rawRgba);
  if (data == null) throw Exception('Không đọc được pixel ảnh');
  return data.buffer.asUint8List();
}
