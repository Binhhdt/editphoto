/// Cac ham tao ma tran mau 4x5 (20 so) dung cho ColorFilter.matrix.
/// Cot thu 5 la do lech, tinh theo thang 0..255.
class CM {
  static const List<double> identity = [
    1, 0, 0, 0, 0,
    0, 1, 0, 0, 0,
    0, 0, 1, 0, 0,
    0, 0, 0, 1, 0,
  ];

  static const List<double> sepia = [
    0.393, 0.769, 0.189, 0, 0,
    0.349, 0.686, 0.168, 0, 0,
    0.272, 0.534, 0.131, 0, 0,
    0, 0, 0, 1, 0,
  ];

  /// Ket qua = ap dung [first] truoc, roi [second].
  static List<double> concat(List<double> first, List<double> second) {
    final out = List<double>.filled(20, 0);
    for (int r = 0; r < 4; r++) {
      for (int c = 0; c < 5; c++) {
        double v = 0;
        for (int k = 0; k < 4; k++) {
          v += second[r * 5 + k] * first[k * 5 + c];
        }
        if (c == 4) v += second[r * 5 + 4];
        out[r * 5 + c] = v;
      }
    }
    return out;
  }

  static List<double> chain(List<List<double>> list) {
    List<double> m = identity;
    for (final x in list) {
      m = concat(m, x);
    }
    return m;
  }

  static List<double> offset(double v) => [
        1, 0, 0, 0, v,
        0, 1, 0, 0, v,
        0, 0, 1, 0, v,
        0, 0, 0, 1, 0,
      ];

  static List<double> scale(double r, double g, double b) => [
        r, 0, 0, 0, 0,
        0, g, 0, 0, 0,
        0, 0, b, 0, 0,
        0, 0, 0, 1, 0,
      ];

  static List<double> contrast(double c) {
    final t = 127.5 * (1 - c);
    return [
      c, 0, 0, 0, t,
      0, c, 0, 0, t,
      0, 0, c, 0, t,
      0, 0, 0, 1, 0,
    ];
  }

  static List<double> saturation(double s) {
    const lr = 0.2126, lg = 0.7152, lb = 0.0722;
    final i = 1 - s;
    return [
      lr * i + s, lg * i, lb * i, 0, 0,
      lr * i, lg * i + s, lb * i, 0, 0,
      lr * i, lg * i, lb * i + s, 0, 0,
      0, 0, 0, 1, 0,
    ];
  }

  /// Tron giua identity va [m] theo ti le t (0..1).
  static List<double> mix(List<double> m, double t) {
    final out = List<double>.filled(20, 0);
    for (int i = 0; i < 20; i++) {
      out[i] = identity[i] + (m[i] - identity[i]) * t;
    }
    return out;
  }
}
