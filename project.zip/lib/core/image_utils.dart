import 'dart:typed_data';
import 'dart:ui' as ui;

/// Giai ma bytes (JPG/PNG/WebP) thanh ui.Image. Tu xoay theo EXIF.
Future<ui.Image> decodeImage(Uint8List bytes) async {
  final codec = await ui.instantiateImageCodec(bytes);
  final frame = await codec.getNextFrame();
  codec.dispose();
  return frame.image;
}

/// Ve len canvas roi tra ve anh moi kich thuoc width x height.
Future<ui.Image> renderImage(
  int width,
  int height,
  void Function(ui.Canvas canvas) paint,
) async {
  final recorder = ui.PictureRecorder();
  final canvas = ui.Canvas(recorder);
  paint(canvas);
  final picture = recorder.endRecording();
  final image = await picture.toImage(width, height);
  picture.dispose();
  return image;
}

/// Thu nho anh neu canh dai vuot qua [maxSide]. Anh goc bi dispose neu thu nho.
Future<ui.Image> limitSize(ui.Image src, double maxSide) async {
  final longest = src.width > src.height ? src.width : src.height;
  if (longest <= maxSide) return src;
  final k = maxSide / longest;
  final w = (src.width * k).round();
  final h = (src.height * k).round();
  final out = await renderImage(w, h, (c) {
    c.drawImageRect(
      src,
      ui.Rect.fromLTWH(0, 0, src.width.toDouble(), src.height.toDouble()),
      ui.Rect.fromLTWH(0, 0, w.toDouble(), h.toDouble()),
      ui.Paint()..filterQuality = ui.FilterQuality.high,
    );
  });
  src.dispose();
  return out;
}

/// Ap ma tran mau that su len pixel anh.
Future<ui.Image> applyColorMatrix(ui.Image src, List<double> matrix) {
  return renderImage(src.width, src.height, (c) {
    c.drawImage(
      src,
      ui.Offset.zero,
      ui.Paint()..colorFilter = ui.ColorFilter.matrix(matrix),
    );
  });
}
