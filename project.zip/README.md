# Photo Editor (Flutter, Android) - Version 1

## Cau truc thu muc
```
.github/workflows/build.yml      Build APK tren GitHub Actions
pubspec.yaml
lib/
  main.dart
  core/
    app_config.dart              Gioi han kich thuoc anh, so buoc undo, mau
    color_matrix.dart            Ma tran mau
    image_utils.dart             Giai ma, render, ap ma tran len pixel
  features/
    picker/image_picker_service.dart
    camera/camera_service.dart
    editor/editor_controller.dart, editor_screen.dart
    editor/widgets/              image_stage, tool_button, color_row
    history/history_manager.dart
    crop/                        crop_ops, crop_view, crop_panel
    transform/                   transform_ops, transform_panel
    adjust/                      adjust_model, adjust_panel
    filters/                     filter_presets, filter_panel
    draw/                        draw_model, draw_view, draw_panel
    text/                        text_model, text_view, text_panel
    export/                      export_service, export_sheet
    share/share_service.dart
```
Thu muc android/ duoc workflow tu tao bang `flutter create`.
